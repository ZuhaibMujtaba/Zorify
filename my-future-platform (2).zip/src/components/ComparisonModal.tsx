import React from 'react';
import { X, Star, Shield, Truck, AlertTriangle, ShoppingCart, Info, CheckCircle2 } from 'lucide-react';
import { Product, SellerOffer } from '../types';
import { getOffersForProduct } from '../data';

interface ComparisonModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, seller: any) => void;
  currency: 'USD' | 'PKR';
}

export default function ComparisonModal({
  product,
  isOpen,
  onClose,
  onAddToCart,
  currency
}: ComparisonModalProps) {
  if (!isOpen || !product) return null;

  const offers = getOffersForProduct(product.id);

  const getPriceSymbol = () => (currency === 'USD' ? '$' : 'PKR');

  const formatPrice = (pkr: number, usd: number) => {
    const val = currency === 'USD' ? usd : pkr;
    return currency === 'USD' ? `${getPriceSymbol()}${val.toLocaleString()}` : `${getPriceSymbol()} ${val.toLocaleString()}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto" role="dialog" aria-modal="true">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-gray-900/60 backdrop-blur-xs transition-opacity" 
        onClick={onClose} 
      />

      {/* Container */}
      <div className="relative bg-white rounded-3xl w-full max-w-3xl shadow-2xl overflow-hidden z-10 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-50/70">
          <div>
            <span className="text-[10px] font-extrabold text-[#002045]/60 uppercase tracking-widest bg-[#002045]/5 px-2.5 py-1 rounded-md">
              Multi-Seller Comparison Engine
            </span>
            <h2 className="text-sm font-bold text-gray-900 mt-1">
              Compare Sellers for: <strong className="text-[#002045] font-extrabold">{product.title}</strong>
            </h2>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 hover:bg-gray-100 rounded-full text-gray-400 hover:text-gray-600 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* Main Item Brief */}
          <div className="flex flex-col md:flex-row gap-5 p-4 bg-gray-50/60 border border-gray-100 rounded-2xl">
            <img 
              src={product.image} 
              alt={product.title} 
              className="w-24 h-24 object-cover rounded-xl border border-gray-200 bg-white"
              referrerPolicy="no-referrer"
            />
            <div className="space-y-1.5 flex-1 text-xs">
              <span className="font-bold text-emerald-600 text-[10px] uppercase tracking-wider">{product.category}</span>
              <h3 className="text-base font-extrabold text-[#002045]">{product.title}</h3>
              <p className="text-gray-500 text-[11px] leading-relaxed max-w-xl">{product.description}</p>
              {product.specifications && (
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 pt-2 border-t border-gray-200/50 text-[10px]">
                  {Object.entries(product.specifications).slice(0, 4).map(([k, v]) => (
                    <div key={k} className="truncate">
                      <span className="text-gray-400 font-medium">{k}:</span> <span className="text-gray-700 font-semibold">{v}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* AI Advisor Tag */}
          <div className="bg-sky-50 border border-sky-100 p-3.5 rounded-xl flex items-start gap-3">
            <Info className="w-4 h-4 text-sky-600 mt-0.5 flex-shrink-0" />
            <div className="text-[11px] text-sky-800 leading-relaxed">
              <strong>Escrow AI Shield enabled:</strong> Our algorithm monitors every single transacting seller below. Their quality scores evaluate past disputes, dispatch delays, and safety audits. Your transaction remains 100% insured under Safe Buy terms regardless of who you pick.
            </div>
          </div>

          {/* Comparison Table / List */}
          <div className="space-y-4">
            <h4 className="text-xs font-extrabold text-gray-900 uppercase tracking-wider">Available Verified Merchant Offers</h4>
            
            <div className="space-y-3.5">
              {offers.map((offer) => {
                const isWinner = offer.reliabilityScore >= 95;
                return (
                  <div 
                    key={offer.sellerId}
                    className={`p-4 rounded-2xl border-2 transition-all flex flex-col md:flex-row justify-between items-start md:items-center gap-4 ${isWinner ? 'border-emerald-500/30 bg-emerald-50/5/30 hover:border-emerald-500' : 'border-gray-100 bg-white hover:border-gray-200'}`}
                  >
                    
                    {/* Seller Profile */}
                    <div className="flex items-center gap-3 min-w-48">
                      <img 
                        src={offer.sellerAvatar} 
                        alt={offer.sellerName} 
                        className="w-10 h-10 rounded-full border border-gray-200 object-cover bg-white"
                        referrerPolicy="no-referrer"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-gray-900 truncate">{offer.sellerName}</span>
                          {offer.isVerified && (
                            <span 
                              className="text-[9px] bg-emerald-50 text-emerald-700 font-extrabold px-1.5 py-0.5 rounded flex items-center gap-0.5"
                              title="ZV Verified Merchant"
                            >
                              <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600" />
                              ZV
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-1 text-[11px] text-gray-500 mt-0.5">
                          <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                          <span>{offer.sellerRating.toFixed(2)}</span>
                        </div>
                      </div>
                    </div>

                    {/* ZV Reliability Rating */}
                    <div className="flex flex-col items-start md:items-center">
                      <span className="text-[10px] text-gray-400 font-semibold uppercase tracking-wider mb-0.5">ZV SCORE</span>
                      <div className="flex items-center gap-1.5">
                        <span className={`text-xs font-extrabold px-2 py-0.5 rounded-lg ${offer.reliabilityScore >= 95 ? 'bg-emerald-100 text-emerald-800' : offer.reliabilityScore >= 90 ? 'bg-indigo-100 text-indigo-800' : 'bg-amber-100 text-amber-800'}`}>
                          {offer.reliabilityScore}%
                        </span>
                        <span className="text-[10px] text-gray-500 font-medium">
                          {offer.reliabilityScore >= 95 ? 'Excellent' : 'Trustworthy'}
                        </span>
                      </div>
                    </div>

                    {/* Logistics */}
                    <div className="flex items-center gap-2 text-xs text-gray-600">
                      <Truck className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="font-semibold text-gray-900 text-[11px]">{offer.deliveryDays} Day Delivery</p>
                        <p className="text-[10px] text-gray-400">{offer.sellerId === 'prime-global' ? 'Lahore Depot' : 'Dubai Outlet'}</p>
                      </div>
                    </div>

                    {/* Price and Add button */}
                    <div className="flex items-center justify-between w-full md:w-auto md:justify-end gap-5 border-t border-gray-100 pt-3 md:border-none md:pt-0">
                      <div className="text-left md:text-right">
                        <p className="text-sm font-extrabold text-emerald-600">
                          {formatPrice(offer.pricePKR, offer.priceUSD)}
                        </p>
                        <p className={`text-[10px] uppercase font-bold tracking-wider mt-0.5 ${offer.stockStatus === 'Low Stock' ? 'text-amber-500' : 'text-gray-400'}`}>
                          {offer.stockStatus}
                        </p>
                      </div>

                      <button
                        onClick={() => onAddToCart(product, offer)}
                        className="bg-[#002045] hover:bg-[#003060] text-white font-bold py-2 px-4 rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
                      >
                        <ShoppingCart className="w-3.5 h-3.5" />
                        Buy Offer
                      </button>
                    </div>
                    
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4.5 border-t border-gray-100 bg-gray-50 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs text-gray-500">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-500" />
            <span>Under protected escrow contract bounds, standard checkout applies.</span>
          </div>
          <button 
            onClick={onClose}
            className="font-bold text-gray-600 hover:text-gray-900 cursor-pointer self-end"
          >
            Close comparison
          </button>
        </div>

      </div>
    </div>
  );
}
