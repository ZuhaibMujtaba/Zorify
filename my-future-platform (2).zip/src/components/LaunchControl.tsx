import React, { useState, useEffect } from 'react';
import { jsPDF } from 'jspdf';
import { 
  ShieldCheck, 
  KeyRound, 
  Activity, 
  HardDriveDownload, 
  RotateCcw, 
  Sparkles, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  AlertTriangle, 
  CreditCard, 
  BookOpen, 
  Download, 
  X, 
  ShieldAlert,
  Fingerprint,
  ArrowRight,
  TrendingUp,
  Cpu
} from 'lucide-react';

interface LaunchControlProps {
  onClose: () => void;
  currency: 'USD' | 'PKR';
  onLoginSuccess?: (user: { id: string; username: string; role: 'buyer' | 'seller' | 'admin'; sessionToken: string }) => void;
}

export default function LaunchControl({ onClose, currency, onLoginSuccess }: LaunchControlProps) {
  // Navigation tabs inside launcher control
  const [activeSubTab, setActiveSubTab] = useState<'security' | 'database' | 'analytics' | 'policies'>('security');

  // Security tests states
  // 1. Bcrypt Password Hashing Sandbox
  const [regUser, setRegUser] = useState('');
  const [regPass, setRegPass] = useState('');
  const [regRole, setRegRole] = useState<'buyer' | 'seller' | 'admin'>('buyer');
  const [regResult, setRegResult] = useState<any>(null);
  const [showRegPass, setShowRegPass] = useState(false);
  const [loginUser, setLoginUser] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [loginResult, setLoginResult] = useState<any>(null);
  const [showLoginPass, setShowLoginPass] = useState(false);
  const [hashingLoading, setHashingLoading] = useState(false);
  const [loginLoading, setLoginLoading] = useState(false);

  // 2. Custom API Rate Limiter Throttle Trial
  const [rateLimitTrials, setRateLimitTrials] = useState<any[]>([]);
  const [rateLimitStatus, setRateLimitStatus] = useState<'ready' | 'cooldown' | 'blocked'>('ready');
  const [rateLimitBlockedMessage, setRateLimitBlockedMessage] = useState('');
  const [remainingTokens, setRemainingTokens] = useState<number>(10);
  const [cooldownTime, setCooldownTime] = useState<number>(0);
  const [hitCount, setHitCount] = useState(0);

  // 3. SQL Injection Shield Trial
  const [sqlPayload, setSqlPayload] = useState("' OR 1=1 --");
  const [sqlResult, setSqlResult] = useState<any>(null);
  const [sqlStatus, setSqlStatus] = useState<'neutral' | 'blocked' | 'passed'>('neutral');

  // 4. Live Security Audit Streams
  const [securityLogs, setSecurityLogs] = useState<any[]>([]);
  const [logsSearchQuery, setLogsSearchQuery] = useState('');
  const [logsSortOrder, setLogsSortOrder] = useState<'newest' | 'oldest'>('newest');

  // 5. Payment ESCROW testing workflow
  const [billingName, setBillingName] = useState('John Doe');
  const [billingCard, setBillingCard] = useState('4111 2222 3333 4444');
  const [billingAddress, setBillingAddress] = useState('Marina Walk, Dubai, UAE');
  const [payMethod, setPayMethod] = useState<'Visa' | 'Easypaisa' | 'JazzCash' | 'Mada'>('Visa');
  const [paymentResult, setPaymentResult] = useState<any>(null);
  const [paymentLoading, setPaymentLoading] = useState(false);

  // Load audit logs from server
  const fetchLogs = async () => {
    try {
      const res = await fetch('/api/admin/security-logs');
      const data = await res.json();
      setSecurityLogs(data);
    } catch (e) {
      console.error('Error fetching logs:', e);
    }
  };

  useEffect(() => {
    fetchLogs();
    const interval = setInterval(fetchLogs, 8000);
    return () => clearInterval(interval);
  }, []);

  // Cooldown rate limiter countdown
  useEffect(() => {
    if (cooldownTime > 0) {
      const timer = setTimeout(() => {
        setCooldownTime(prev => prev - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (rateLimitStatus === 'cooldown' || rateLimitStatus === 'blocked') {
      setRateLimitStatus('ready');
    }
  }, [cooldownTime, rateLimitStatus]);

  // Handler 1: Bcrypt signup simulation
  const handleBcryptRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regUser || !regPass) return;
    setHashingLoading(true);
    setRegResult(null);
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: regUser, password: regPass, role: regRole })
      });
      const data = await response.json();
      if (!response.ok) {
        setRegResult({ error: data.error || 'Server rejected registration.' });
      } else {
        setRegResult(data);
        // Pre-fill login user for seamless interaction
        setLoginUser(regUser);
      }
      fetchLogs();
    } catch (err: any) {
      setRegResult({ error: err.message || 'Network exception.' });
    } finally {
      setHashingLoading(false);
    }
  };

  const handleBcryptLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginUser || !loginPass) return;
    setLoginLoading(true);
    setLoginResult(null);
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: loginUser, password: loginPass })
      });
      const data = await response.json();
      if (!response.ok) {
        setLoginResult({ error: data.error || 'Login verification failed.' });
      } else {
        setLoginResult(data);
        if (onLoginSuccess) {
          onLoginSuccess({
            id: data.role === 'admin' ? 'USR-ADMIN' : (data.role === 'seller' ? 'USR-SELLER' : 'USR-BUYER'),
            username: data.username,
            role: data.role,
            sessionToken: data.sessionToken
          });
        }
      }
      fetchLogs();
    } catch (err: any) {
      setLoginResult({ error: err.message || 'Network logon exception.' });
    } finally {
      setLoginLoading(false);
    }
  };

  // Handler 2: Trigger API limit query check
  const handleRateLimitTrigger = async () => {
    setHitCount(prev => prev + 1);
    try {
      const response = await fetch('/api/test/rate-limit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await response.json();
      
      const newTrial = {
        index: hitCount + 1,
        timestamp: new Date().toLocaleTimeString(),
        status: response.status,
        remaining: response.headers.get('X-RateLimit-Remaining') || '0',
        message: data.message || 'Limit OK'
      };

      setRateLimitTrials(prev => [newTrial, ...prev].slice(0, 5));

      if (response.status === 429) {
        setRateLimitStatus('blocked');
        setRateLimitBlockedMessage(data.message);
        setCooldownTime(data.resetInSeconds || 45);
        setRemainingTokens(0);
      } else {
        setRemainingTokens(Number(response.headers.get('X-RateLimit-Remaining') || 10));
      }
      fetchLogs();
    } catch (e) {
      console.error(e);
    }
  };

  // Handler 3: SQL inject validation
  const handleSqlInjectTest = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/test/sql-protect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ injectionPayload: sqlPayload })
      });
      const data = await response.json();
      
      setSqlResult(data);
      if (response.status === 403) {
        setSqlStatus('blocked');
      } else {
        setSqlStatus('passed');
      }
      fetchLogs();
    } catch (err: any) {
      setSqlResult({ error: err.message || 'Connection crashed' });
    }
  };

  // Handler 4: Trigger Download db backup JSON
  const handleDownloadBackup = () => {
    window.location.href = '/api/admin/backup';
    fetchLogs();
  };

  // Handler 5: Custom full payment flow test
  const handlePaymentTest = async (e: React.FormEvent) => {
    e.preventDefault();
    setPaymentLoading(true);
    setPaymentResult(null);
    try {
      const response = await fetch('/api/checkout/payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cartItems: [],
          fullName: billingName,
          phone: '+971-55-900392',
          address: billingAddress,
          paymentMethod: payMethod,
          currencyState: currency,
          totalCost: currency === 'USD' ? 105 : 29000
        })
      });
      const data = await response.json();
      setPaymentResult(data);
      fetchLogs();
    } catch (err: any) {
      setPaymentResult({ error: err.message || 'Payment system check failed.' });
    } finally {
      setPaymentLoading(false);
    }
  };

  // Handler for exporting audit logs as .txt file
  const handleExportLogs = () => {
    const header = `==================================================\n` +
                   `ZORIFY AI-COMMERCE MARKETPLACE: APPLET SECURITY AUDIT REPORT\n` +
                   `Session Exported At: ${new Date().toISOString()}\n` +
                   `CORS Policy: Active (Header origin: *)\n` +
                   `Helmet HSTS Policy: Active (Strict)\n` +
                   `HTTPS Simulation: Active\n` +
                   `==================================================\n\n`;
    
    let body = "";
    if (securityLogs.length === 0) {
      body = "No security logs recorded in current session.\n";
    } else {
      body = securityLogs.map((log, index) => {
        return `[${index + 1}] Timestamp: ${new Date(log.timestamp).toLocaleString()}\n` +
               `    Event Type: ${log.type}\n` +
               `    Message: ${log.message}\n` +
               `--------------------------------------------------`;
      }).join('\n');
    }

    const fileContent = header + body;
    const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `zorify_security_audit_logs_${Date.now()}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Handler for exporting audit logs as fully formatted PDF
  const handleExportPDF = () => {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    // Dark blue hero branding block
    doc.setFillColor(0, 32, 69);
    doc.rect(0, 0, 210, 42, 'F');

    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.text('ZORIFY SECURITY CENTRIC JOURNAL', 15, 18);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(200, 210, 225);
    doc.text('COMPLIANCE DECK AUDIT REPORT & THREAT MITIGATION LOGS', 15, 24);

    doc.setFillColor(16, 185, 129); // Accent border emerald line
    doc.rect(15, 28, 60, 1.3, 'F');

    doc.setTextColor(230, 235, 245);
    doc.setFontSize(7.5);
    doc.setFont('courier', 'bold');
    doc.text(`DATE GENERATED: ${new Date().toLocaleString()}`, 15, 34);
    doc.text('PROTECTION SHIELD STATUS: ONLINE', 135, 34);

    // Metadata Info Section
    let currY = 56;
    doc.setTextColor(0, 32, 69);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.text('Interactive Host Environment Profile', 15, currY);
    doc.setDrawColor(226, 232, 240);
    doc.line(15, currY + 2.5, 195, currY + 2.5);

    currY += 9;
    doc.setFontSize(8.5);
    doc.setTextColor(45, 55, 72);
    
    doc.setFont('helvetica', 'bold'); doc.text('Server Ingress Agent:', 15, currY);
    doc.setFont('helvetica', 'normal'); doc.text('Secure Express Shield Container Core v3.1.2', 54, currY);
    
    doc.setFont('helvetica', 'bold'); doc.text('HSTS Strict Safety Header:', 15, currY + 5.5);
    doc.setFont('helvetica', 'normal'); doc.text('Strict-Transport-Security Max-Age Locked', 54, currY + 5.5);

    doc.setFont('helvetica', 'bold'); doc.text('Whitelisted CORS Scopes:', 115, currY);
    doc.setFont('helvetica', 'normal'); doc.text('Unified API Proxy (Host origin: *)', 155, currY);
    
    doc.setFont('helvetica', 'bold'); doc.text('Sanitizer Shield Engine:', 115, currY + 5.5);
    doc.setFont('helvetica', 'normal'); doc.text('SQL Injection Attack Interceptor', 155, currY + 5.5);

    currY += 19;

    // Table Header Area
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(0, 32, 69);
    doc.text('Captured Verification Logs & Intrusion Blocks', 15, currY);
    doc.line(15, currY + 2.5, 195, currY + 2.5);

    currY += 8;

    // Draw Column Headers
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(115, 125, 140);
    doc.text('#', 15, currY);
    doc.text('TIMESTAMP / UTC OFFSET', 22, currY);
    doc.text('EVENT ID / CLASS', 76, currY);
    doc.text('LOG TRANSACTION RECORD DETAILS', 115, currY);
    
    doc.setDrawColor(200, 205, 215);
    doc.line(15, currY + 2, 195, currY + 2);
    currY += 7;

    doc.setFont('helvetica', 'normal');
    if (securityLogs.length === 0) {
      doc.setTextColor(160, 160, 160);
      doc.text('(No logs recorded or captured in current system state cache)', 15, currY);
    } else {
      securityLogs.forEach((log, index) => {
        // Break page check
        if (currY > 270) {
          doc.addPage();
          // Header of next page
          doc.setFillColor(0, 32, 69);
          doc.rect(0, 0, 210, 15, 'F');
          doc.setTextColor(255, 255, 255);
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(9);
          doc.text('ZORIFY COMPLIANCE SECURED LOGBOOK (CONTINUED)', 15, 10);
          currY = 25;

          doc.setFontSize(8);
          doc.setFont('helvetica', 'bold');
          doc.setTextColor(115, 125, 140);
          doc.text('#', 15, currY);
          doc.text('TIMESTAMP / UTC OFFSET', 22, currY);
          doc.text('EVENT ID / CLASS', 76, currY);
          doc.text('LOG TRANSACTION RECORD DETAILS', 115, currY);
          
          doc.setDrawColor(200, 205, 215);
          doc.line(15, currY + 2, 195, currY + 2);
          currY += 7;
          doc.setFont('helvetica', 'normal');
        }

        // Alternating row styling
        if (index % 2 === 0) {
          doc.setFillColor(247, 250, 252);
          doc.rect(14, currY - 3.5, 182, 8.5, 'F');
        }

        doc.setTextColor(60, 65, 75);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(7.5);
        doc.text(String(index + 1), 15, currY);

        try {
          const rawDate = new Date(log.timestamp);
          const eventTimeDetail = isNaN(rawDate.getTime()) ? 'N/A' : `${rawDate.toLocaleDateString()} ${rawDate.toLocaleTimeString()}`;
          doc.text(eventTimeDetail, 22, currY);
        } catch (err) {
          doc.text('Date Parse Fail', 22, currY);
        }

        // Color coding Event Types
        const isCritical = log.type.includes('BLOCKED') || log.type.includes('FAIL') || log.type.includes('ERROR');
        if (isCritical) {
          doc.setTextColor(220, 38, 38); 
          doc.setFont('helvetica', 'bold');
        } else {
          doc.setTextColor(16, 124, 76); 
          doc.setFont('helvetica', 'bold');
        }
        doc.text(String(log.type || 'EVENT'), 76, currY);

        doc.setTextColor(45, 55, 72);
        doc.setFont('helvetica', 'normal');
        let detailText = String(log.message || '');
        if (detailText.length > 58) {
          detailText = detailText.slice(0, 54) + '...';
        }
        doc.text(detailText, 115, currY);

        doc.setDrawColor(241, 245, 249);
        doc.line(15, currY + 5, 195, currY + 5);

        currY += 8.5;
      });
    }

    doc.setFontSize(7);
    doc.setFont('courier', 'bold');
    doc.setTextColor(160, 165, 175);
    doc.text('Zorify Cryptographic Shield (c) 2026. Automated Client-Side Security Document.', 15, 287);
    doc.text('Page 1 of 1', 180, 287);

    doc.save(`zorify_security_audit_report_${Date.now()}.pdf`);
  };


  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
      {/* Dark overlay backdrop */}
      <div className="absolute inset-0 bg-[#001025]/85 backdrop-blur-sm cursor-pointer" onClick={onClose} />
      
      {/* Launch Control Panel Frame */}
      <div 
        className="relative bg-white rounded-[2rem] w-full max-w-5xl h-[88vh] flex flex-col overflow-hidden shadow-2xl z-10 border border-white/20 text-slate-800"
        id="launch-checklist-pnl"
      >
        
        {/* Dynamic Header Block with Cyber Protection styling */}
        <div className="bg-[#002045] text-white p-6 shrink-0 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-emerald-500 rounded-xl text-white shadow-lg shadow-emerald-500/20 animate-pulse">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-emerald-500/20 text-emerald-400 text-[9px] font-extrabold px-2 py-0.5 rounded-full border border-emerald-500/30">
                  SHIELD ACTIVE
                </span>
                <span className="text-[10px] text-gray-400 mt-0.5">HTTPS & CORS LOCKED</span>
              </div>
              <h2 className="text-lg font-black tracking-tight flex items-center gap-2">
                Cybersecurity & Launch Control Desk
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Status indicator badge */}
            <div className="hidden sm:block text-right">
              <p className="text-[9px] font-bold text-emerald-400 tracking-wider">PAGE STATUS</p>
              <p className="text-xs font-semibold text-gray-300">Speed <strong className="text-emerald-400 font-bold">&#60; 1.3s</strong> (Vite Optimizations)</p>
            </div>
            
            <button 
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-full transition-colors cursor-pointer"
            >
              <X className="w-5 h-5 text-gray-400 hover:text-white" />
            </button>
          </div>
        </div>

        {/* Interior layout body splits into left rail navigation and right action viewport */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden bg-gray-50/50">
          
          {/* Sub Navigation Left Sidebar */}
          <div className="w-full md:w-64 bg-white border-r border-gray-150 p-4 shrink-0 flex flex-col justify-between">
            <div className="space-y-1">
              <p className="px-3 pb-2 text-[10px] font-extrabold text-[#002045]/50 tracking-wider uppercase">Active Components</p>
              
              <button
                onClick={() => setActiveSubTab('security')}
                className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl font-bold text-xs cursor-pointer transition-all ${activeSubTab === 'security' ? 'bg-[#002045]/5 text-[#002045] border-l-4 border-emerald-500 font-black' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'}`}
              >
                <Fingerprint className="w-4 h-4 text-emerald-600" />
                Security Sandbox
              </button>

              <button
                onClick={() => setActiveSubTab('database')}
                className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl font-bold text-xs cursor-pointer transition-all ${activeSubTab === 'database' ? 'bg-[#002045]/5 text-[#002045] border-l-4 border-indigo-500 font-black' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'}`}
              >
                <HardDriveDownload className="w-4 h-4 text-indigo-600" />
                Database & Backup
              </button>

              <button
                onClick={() => setActiveSubTab('analytics')}
                className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl font-bold text-xs cursor-pointer transition-all ${activeSubTab === 'analytics' ? 'bg-[#002045]/5 text-[#002045] border-l-4 border-[#002045] font-black' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'}`}
              >
                <Activity className="w-4 h-4 text-[#002045]" />
                Live Shop Analytics
              </button>

              <button
                onClick={() => setActiveSubTab('policies')}
                className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl font-bold text-xs cursor-pointer transition-all ${activeSubTab === 'policies' ? 'bg-[#002045]/5 text-[#002045] border-l-4 border-sky-500 font-black' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'}`}
              >
                <BookOpen className="w-4 h-4 text-sky-600" />
                Legal Agreements
              </button>
            </div>

            {/* Micro security metrics footer */}
            <div className="bg-[#002045]/5 p-3 rounded-xl border border-[#002045]/10 space-y-1.5 hidden md:block text-slate-700">
              <div className="flex justify-between text-[10px] items-center">
                <span className="font-bold">CORS Policy:</span>
                <span className="text-emerald-600 font-black">ACTIVE</span>
              </div>
              <div className="flex justify-between text-[10px] items-center">
                <span className="font-bold">Helmet HSTS:</span>
                <span className="text-emerald-600 font-black">STRICT</span>
              </div>
              <div className="flex justify-between text-[10px] items-center">
                <span className="font-bold">SQL Sanitization:</span>
                <span className="text-emerald-600 font-black">ENABLED</span>
              </div>
            </div>
          </div>

          {/* Master view panel containing target tab components */}
          <div className="flex-1 p-6 overflow-y-auto bg-white">
            
            {/* SUBTAB 1: SECURITY EXPERIMENTS SANDBOX */}
            {activeSubTab === 'security' && (
              <div className="space-y-8 animate-fade-in text-left">
                <div>
                  <h3 className="text-base font-extrabold text-[#002045]">Core Security & Shield Sandboxes</h3>
                  <p className="text-xs text-gray-400 mt-1">Simulate real-world cybersecurity attacks and password authentication hashing directly on our live Express backend.</p>
                </div>

                {/* Grid layout for Bcrypt and Rate limiter */}
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                  
                  {/* Test Box A: Password Hashing via blowfish bcryptjs */}
                  <div className="bg-gray-50/70 border border-gray-150 p-5 rounded-2xl space-y-4 shadow-sm">
                    <div className="flex items-center gap-2 border-b border-gray-200/60 pb-3">
                      <KeyRound className="w-5 h-5 text-[#002045]" />
                      <div>
                        <h4 className="font-extrabold text-[#002045] text-xs">A. Blowfish Bcrypt Hashing Sandbox</h4>
                        <p className="text-[10px] text-gray-400 mt-0.5">Passwords are registered with dynamic salt rounds=10.</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Register form */}
                      <form onSubmit={handleBcryptRegister} className="space-y-2.5">
                        <p className="text-[10px] font-black uppercase text-indigo-700 tracking-wider">1. Signup Registration</p>
                        <input 
                          type="text"
                          required
                          placeholder="Merchant Username"
                          value={regUser}
                          onChange={(e) => setRegUser(e.target.value)}
                          className="w-full px-3 py-1.5 bg-white border border-gray-200 text-[#002045] text-xs rounded-lg focus:outline-none focus:border-[#002045]"
                        />
                        <div className="relative">
                          <input 
                            type={showRegPass ? 'text' : 'password'}
                            required
                            placeholder="Plaintext Password"
                            value={regPass}
                            onChange={(e) => setRegPass(e.target.value)}
                            className="w-full px-3 py-1.5 pr-8 bg-white border border-gray-200 text-[#002045] text-xs rounded-lg focus:outline-none focus:border-[#002045]"
                          />
                          <button 
                            type="button"
                            onClick={() => setShowRegPass(!showRegPass)}
                            className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-gray-400 hover:text-gray-600 rounded"
                          >
                            {showRegPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                        <div>
                          <label className="block text-[9px] font-extrabold text-gray-500 mb-0.5 uppercase">Select Operations Role</label>
                          <select
                            value={regRole}
                            onChange={(e: any) => setRegRole(e.target.value)}
                            className="w-full px-2 py-1 bg-white border border-gray-200 rounded text-xs font-bold font-sans text-gray-800"
                          >
                            <option value="buyer">Buyer (Default Clientele)</option>
                            <option value="seller">Seller (Direct Dropship Vendor)</option>
                            <option value="admin">Administrator (Safe Guard Custodian)</option>
                          </select>
                        </div>
                        <button 
                          type="submit"
                          disabled={hashingLoading}
                          className="w-full bg-[#002045] text-white hover:bg-[#003060] transition-colors py-2 rounded-lg font-bold text-[11px] cursor-pointer"
                        >
                          {hashingLoading ? 'Computing Salt Hash...' : 'Register Secure Creds'}
                        </button>
                      </form>

                      {/* Login Validation Form */}
                      <form onSubmit={handleBcryptLogin} className="space-y-2.5">
                        <p className="text-[10px] font-black uppercase text-emerald-700 tracking-wider">2. Sign In Verification</p>
                        <input 
                          type="text"
                          required
                          placeholder="Confirm Username"
                          value={loginUser}
                          onChange={(e) => setLoginUser(e.target.value)}
                          className="w-full px-3 py-1.5 bg-white border border-gray-200 text-[#002045] text-xs rounded-lg focus:outline-none focus:border-[#002045]"
                        />
                        <div className="relative">
                          <input 
                            type={showLoginPass ? 'text' : 'password'}
                            required
                            placeholder="Plaintext Password"
                            value={loginPass}
                            onChange={(e) => setLoginPass(e.target.value)}
                            className="w-full px-3 py-1.5 pr-8 bg-white border border-gray-200 text-[#002045] text-xs rounded-lg focus:outline-none focus:border-[#002045]"
                          />
                          <button 
                            type="button"
                            onClick={() => setShowLoginPass(!showLoginPass)}
                            className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-gray-400 hover:text-gray-600 rounded"
                          >
                            {showLoginPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                        <button 
                          type="submit"
                          disabled={loginLoading}
                          className="w-full bg-emerald-600 text-white hover:bg-emerald-700 transition-colors py-2 rounded-lg font-bold text-[11px] cursor-pointer"
                        >
                          {loginLoading ? 'Comparing Hashes...' : 'Authorize Password Match'}
                        </button>
                      </form>
                    </div>

                    {/* Results of registration / login checking rendering */}
                    {regResult && (
                      <div className="p-3 bg-indigo-50 border border-indigo-100 rounded-xl space-y-1 text-[11px]">
                        {regResult.error ? (
                          <p className="text-rose-600 font-bold">Error: {regResult.error}</p>
                        ) : (
                          <>
                            <p className="text-indigo-800 font-bold">Registration Success! Bcrypt hash generated:</p>
                            <p className="font-mono text-[9px] bg-white p-2 rounded border border-indigo-150 break-all select-all text-slate-600">
                              {regResult.passwordHashGenerated}
                            </p>
                            <p className="text-gray-500 text-[10px] mt-1 pt-1 border-t border-indigo-100">
                              Salt Rounds: <strong className="text-slate-700">10 (Blowfish salt: {regResult.saltGenerated})</strong>
                            </p>
                          </>
                        )}
                      </div>
                    )}

                    {loginResult && (
                      <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-xl space-y-1 text-[11px]">
                        {loginResult.error ? (
                          <p className="text-rose-600 font-bold flex items-center gap-1">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            Failed comparison: {loginResult.error}
                          </p>
                        ) : (
                          <>
                            <p className="text-emerald-800 font-bold flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              Login Approved! Compare verified.
                            </p>
                            <p className="text-gray-500 text-[10px]">
                              Bcrypt verified the provided plaintext password matched the encrypted hash block securely.
                            </p>
                          </>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Test Box B: Custom API Rate Limiter Testing */}
                  <div className="bg-gray-50/70 border border-gray-150 p-5 rounded-2xl space-y-4 shadow-sm">
                    <div className="flex items-center justify-between border-b border-gray-200/60 pb-3">
                      <div className="flex items-center gap-2">
                        <Activity className="w-5 h-5 text-indigo-600" />
                        <div>
                          <h4 className="font-extrabold text-[#002045] text-xs">B. Express Rate Limiting Engine</h4>
                          <p className="text-[10px] text-gray-400 mt-0.5">Spam API triggers to authenticate security throttling.</p>
                        </div>
                      </div>
                      <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded ${rateLimitStatus === 'ready' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800 animate-pulse'}`}>
                        {rateLimitStatus === 'ready' ? 'READY' : `BLOCKED (${cooldownTime}s)`}
                      </span>
                    </div>

                    <div className="space-y-3">
                      <p className="text-xs text-gray-500 leading-relaxed">
                        Zorify API rate-limiter prevents denial-of-service threats. Max threshold on testing endpoint: <strong>10 requests/minute</strong>.
                      </p>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-white p-3 rounded-xl border border-gray-150 space-y-1">
                          <span className="text-[9px] text-gray-400 font-bold uppercase tracking-wider">Remaining Tokens</span>
                          <p className="text-lg font-black text-slate-800">{remainingTokens} / 10</p>
                          <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                            <div 
                              className={`h-full transition-all duration-300 ${remainingTokens > 5 ? 'bg-emerald-500' : (remainingTokens > 2 ? 'bg-amber-400' : 'bg-rose-500')}`}
                              style={{ width: `${(remainingTokens / 10) * 100}%` }}
                            />
                          </div>
                        </div>

                        <button 
                          onClick={handleRateLimitTrigger}
                          disabled={rateLimitStatus === 'blocked'}
                          className={`w-full h-full rounded-xl font-bold text-xs flex flex-col items-center justify-center p-3 transition-all border ${rateLimitStatus === 'blocked' ? 'bg-gray-100 border-gray-200 text-gray-400 cursor-not-allowed' : 'bg-[#002045] hover:bg-[#003060] text-white border-transparent cursor-pointer hover:shadow-md'}`}
                        >
                          <span className="text-lg font-extrabold flex items-center gap-1">
                            <Sparkles className="w-4 h-4 text-emerald-400" />
                            Trigger HIT
                          </span>
                          <span className="text-[10px] opacity-70 mt-0.5">Request Test API</span>
                        </button>
                      </div>

                      {/* Display rate limiter trial outputs */}
                      <div className="space-y-1.5">
                        <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Recent Click Log</span>
                        {rateLimitTrials.length === 0 ? (
                          <p className="text-[10px] text-gray-400 italic text-center py-2 bg-white rounded-lg border border-dashed border-gray-200">
                            Click 'Trigger HIT' rapidly to simulate server query volume.
                          </p>
                        ) : (
                          <div className="space-y-1">
                            {rateLimitTrials.map((t, idx) => (
                              <div key={idx} className="flex justify-between text-[10px] bg-white px-2.5 py-1 rounded border border-gray-200">
                                <span className="font-medium text-slate-500">#{t.index} at {t.timestamp}</span>
                                <span className={`font-bold ${t.status === 200 ? 'text-emerald-600' : 'text-rose-600 font-extrabold'}`}>
                                  Status {t.status} (Tokens: {t.remaining})
                                </span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {rateLimitStatus === 'blocked' && (
                        <div className="p-3 bg-rose-50 border border-rose-150 rounded-xl flex items-start gap-2 text-rose-800 text-[11px] animate-fade-in">
                          <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5 animate-bounce" />
                          <div>
                            <span className="font-extrabold uppercase text-[9px] text-rose-600 tracking-wider">THREAT MITIGATED: HTTP 429</span>
                            <p className="font-bold">{rateLimitBlockedMessage}</p>
                            <p className="text-[10px] text-rose-700/80 mt-0.5">Please wait {cooldownTime} seconds while key quota resets.</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                </div>

                {/* Second row layout: SQL injection Sandbox & Live log Stream */}
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 pt-2">
                  
                  {/* Test Box C: SQL Injection sandbox trial */}
                  <div className="bg-gray-50/70 border border-gray-150 p-5 rounded-2xl space-y-4 shadow-sm">
                    <div className="flex items-center gap-2 border-b border-gray-200/60 pb-3">
                      <ShieldCheck className="w-5 h-5 text-indigo-600 animate-pulse" />
                      <div>
                        <h4 className="font-extrabold text-[#002045] text-xs">C. SQL Injection Shield Sandbox</h4>
                        <p className="text-[10px] text-gray-400 mt-0.5">Submit SQL payloads and watch them get intercepted.</p>
                      </div>
                    </div>

                    <form onSubmit={handleSqlInjectTest} className="space-y-3.5 text-xs text-left">
                      <p className="text-gray-500">
                        Type common SQL injection constructs (e.g., `UNION SELECT`, `--`, `OR 1=1`) to test backend parameter validation and sanitation logic.
                      </p>

                      <div className="flex gap-2">
                        <input 
                          type="text"
                          required
                          value={sqlPayload}
                          onChange={(e) => setSqlPayload(e.target.value)}
                          className="w-full px-3.5 py-2.5 bg-white border border-gray-200 rounded-xl focus:outline-none focus:border-[#002045] text-xs font-mono font-bold text-gray-800"
                        />
                        <button 
                          type="submit"
                          className="px-5 bg-[#002045] text-white hover:bg-[#003060] rounded-xl font-bold text-xs shrink-0 cursor-pointer"
                        >
                          Submit Attack
                        </button>
                      </div>

                      <div className="flex flex-wrap gap-2 text-[10px]">
                        <span className="text-gray-400 font-bold self-center">Presets:</span>
                        <button 
                          type="button" 
                          onClick={() => { setSqlPayload("' OR '1'='1"); setSqlStatus('neutral'); }}
                          className="px-2 py-0.5 bg-white hover:bg-gray-150 border border-gray-200 rounded font-mono text-[9px] cursor-pointer"
                        >
                          ' OR '1'='1
                        </button>
                        <button 
                          type="button" 
                          onClick={() => { setSqlPayload("1; DROP TABLE products; --"); setSqlStatus('neutral'); }}
                          className="px-2 py-0.5 bg-white hover:bg-gray-150 border border-gray-200 rounded font-mono text-[9px] cursor-pointer"
                        >
                          DROP TABLE
                        </button>
                        <button 
                          type="button" 
                          onClick={() => { setSqlPayload("normal search query text"); setSqlStatus('neutral'); }}
                          className="px-2 py-0.5 bg-white hover:bg-gray-150 border border-gray-200 rounded font-mono text-[9px] cursor-pointer"
                        >
                          Aesthetically Safe
                        </button>
                      </div>

                      {sqlResult && (
                        <div 
                          className={`p-3 rounded-xl border space-y-1.5 leading-relaxed text-[11px] animate-fade-in ${sqlStatus === 'blocked' ? 'bg-emerald-50 border-emerald-100 text-emerald-800' : 'bg-indigo-50 border-indigo-100 text-indigo-800'}`}
                        >
                          <div className="flex justify-between items-center font-extrabold uppercase text-[9px]">
                            <span>Interception Result</span>
                            <span className={sqlStatus === 'blocked' ? 'text-emerald-600' : 'text-indigo-600'}>
                              {sqlStatus === 'blocked' ? '🔒 SECURE BLOCK (HTTP 403)' : '🟢 UNFILTERED (SAFE PASSTHROUGH)'}
                            </span>
                          </div>
                          
                          <p className="font-bold">{sqlResult.message}</p>
                          {sqlResult.mitigationStatus && (
                            <p className="text-[10px] text-emerald-700/80 italic">{sqlResult.mitigationStatus}</p>
                          )}
                        </div>
                      )}
                    </form>
                  </div>

                  {/* Test Box D: Live Security & Activity monitor */}
                  <div className="bg-gray-50/70 border border-gray-150 p-5 rounded-2xl space-y-4 shadow-sm flex flex-col justify-between">
                    <div className="flex items-center justify-between border-b border-gray-200/60 pb-3">
                      <div className="flex items-center gap-2">
                        <Activity className="w-5 h-5 text-indigo-600" />
                        <div>
                          <h4 className="font-extrabold text-[#002045] text-xs">D. Live Security Audit Streams</h4>
                          <p className="text-[10px] text-gray-400 mt-0.5">Real-time log of security, auth, and throttling events caught by server.</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={handleExportLogs}
                          id="export-security-logs-btn"
                          className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-800 hover:text-emerald-900 font-extrabold text-[10px] transition-all flex items-center gap-1 cursor-pointer rounded-lg"
                          title="Export Current Security Audit Path to TXT file"
                        >
                          <Download className="w-3.5 h-3.5" />
                          TXT
                        </button>
                        <button
                          onClick={handleExportPDF}
                          id="export-security-pdf-btn"
                          className="px-2 py-1 bg-red-50 hover:bg-red-100 border border-red-300 text-red-800 hover:text-red-900 font-extrabold text-[10px] transition-all flex items-center gap-1 cursor-pointer rounded-lg"
                          title="Export Current Security Audit Path to highly formatted PDF document"
                        >
                          <Download className="w-3.5 h-3.5" />
                          PDF
                        </button>
                        <span className="text-[9px] text-gray-400 select-none animate-pulse">● SYNCED</span>
                      </div>
                    </div>

                    {/* Filter and Sort options row */}
                    <div className="flex flex-col sm:flex-row gap-2">
                      <div className="relative flex-1">
                        <input
                          type="text"
                          id="audit-logs-search-input"
                          placeholder="Filter logs by event type or text..."
                          value={logsSearchQuery}
                          onChange={(e) => setLogsSearchQuery(e.target.value)}
                          className="w-full px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-xs placeholder-gray-400 focus:outline-none focus:border-[#002045]"
                        />
                        {logsSearchQuery && (
                          <button
                            onClick={() => setLogsSearchQuery('')}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 font-bold text-xs"
                          >
                            ×
                          </button>
                        )}
                      </div>

                      <button
                        type="button"
                        id="audit-logs-sort-toggle"
                        onClick={() => setLogsSortOrder(prev => prev === 'newest' ? 'oldest' : 'newest')}
                        className="px-3 py-1.5 bg-white hover:bg-gray-50 border border-gray-200 text-slate-700 font-bold text-[11px] rounded-lg cursor-pointer transition-all flex items-center justify-center gap-1 shrink-0"
                        title={`Currently showing ${logsSortOrder === 'newest' ? 'newest first' : 'oldest first'}. Click to toggle.`}
                      >
                        <span className="text-[#002045]">Sort:</span>
                        <span className="text-emerald-600 uppercase font-black">
                          {logsSortOrder === 'newest' ? 'Newest ⬇' : 'Oldest ⬆'}
                        </span>
                      </button>
                    </div>

                    <div className="flex-1 overflow-y-auto max-h-[160px] space-y-2 pr-1 select-text">
                      {(() => {
                        const filtered = securityLogs.filter(log => {
                          const query = logsSearchQuery.toLowerCase();
                          return (log.type || '').toLowerCase().includes(query) || 
                                 (log.message || '').toLowerCase().includes(query);
                        });

                        const sorted = [...filtered].sort((a, b) => {
                          const timeA = new Date(a.timestamp).getTime();
                          const timeB = new Date(b.timestamp).getTime();
                          return logsSortOrder === 'newest' ? timeB - timeA : timeA - timeB;
                        });

                        if (sorted.length === 0) {
                          return (
                            <p className="text-[11px] text-gray-400 italic text-center py-8">
                              {securityLogs.length === 0 ? 'Waiting for kernel logs...' : 'No matching security records found.'}
                            </p>
                          );
                        }
                        return sorted.map((log, i) => {
                          const isThreat = log.type.includes('BLOCKED') || log.type.includes('FAIL') || log.type.includes('ERROR');
                          return (
                            <div key={i} className="bg-white p-2.5 rounded-xl border border-gray-200 flex items-start gap-2.5 text-[10px] leading-relaxed">
                              <span 
                                className={`shrink-0 text-[8px] font-black px-1.5 py-0.5 rounded ${isThreat ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'}`}
                              >
                                {log.type}
                              </span>
                              <div className="flex-1 min-w-0">
                                <p className="text-gray-900 font-medium break-words">{log.message}</p>
                                <span className="text-[8px] text-gray-400 font-mono italic">Time: {new Date(log.timestamp).toLocaleTimeString()}</span>
                              </div>
                            </div>
                          );
                        });
                      })()}
                    </div>

                    <button 
                      onClick={() => { setRateLimitTrials([]); setSqlResult(null); setRegResult(null); setLoginResult(null); }}
                      className="w-full mt-3 py-2 border border-gray-200 hover:border-gray-300 text-gray-500 hover:text-slate-800 rounded-lg text-[10px] font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      Clear Sandbox Views
                    </button>
                  </div>

                </div>
              </div>
            )}

            {/* SUBTAB 2: DATABASE BACKUPS & BACKWARD COMPATIBILITY */}
            {activeSubTab === 'database' && (
              <div className="space-y-8 animate-fade-in text-left">
                <div>
                  <h3 className="text-base font-extrabold text-[#002045]">Database Center & On-demand backups</h3>
                  <p className="text-xs text-gray-400 mt-1">Download secure catalog database backups and verify dynamic payment escrow contract hashing.</p>
                </div>

                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                  
                  {/* Backup Card */}
                  <div className="bg-gray-50/70 border border-gray-150 p-5 rounded-2xl space-y-4 shadow-sm text-xs">
                    <div className="flex items-center gap-2 border-b border-gray-200/60 pb-3">
                      <HardDriveDownload className="w-5 h-5 text-indigo-600" />
                      <div>
                        <h4 className="font-extrabold text-[#002045] text-xs">Dynamic Database Back-ups</h4>
                        <p className="text-[10px] text-gray-400 mt-0.5">Complies with backup, restoration, and JSON portability check.</p>
                      </div>
                    </div>

                    <p className="text-gray-500 leading-relaxed">
                      Instruct the Express server application core to bundle and export catalog product definitions, currently registered sandbox users, and security logs in an encrypted transport-layer JSON backup structure.
                    </p>

                    <div className="bg-white border border-gray-150 p-3.5 rounded-xl space-y-2 text-[11px] text-slate-700/80">
                      <div className="flex justify-between font-mono">
                        <span>Cluster:</span> <strong className="text-slate-900 font-bold">Zorify-Production-East</strong>
                      </div>
                      <div className="flex justify-between font-mono">
                        <span>Backup Spec:</span> <strong className="text-slate-900 font-bold">Full JSON Dump</strong>
                      </div>
                      <div className="flex justify-between font-mono">
                        <span>Encryption Key:</span> <strong className="text-emerald-600 font-extrabold">Active (256-Bit)</strong>
                      </div>
                    </div>

                    <button
                      onClick={handleDownloadBackup}
                      className="w-full bg-[#002045] hover:bg-[#003060] text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer text-xs"
                    >
                      <Download className="w-4 h-4 text-emerald-400" />
                      Download Database backup (dump.json)
                    </button>
                  </div>

                  {/* Payment Verification Card - PAYMENT FLOW TESTED */}
                  <div className="bg-gray-50/70 border border-gray-150 p-5 rounded-2xl space-y-4 shadow-sm text-xs">
                    <div className="flex items-center gap-2 border-b border-gray-200/60 pb-3">
                      <CreditCard className="w-5 h-5 text-emerald-600 animate-pulse" />
                      <div>
                        <h4 className="font-extrabold text-[#002045] text-xs">Escrow Protection Payment Flow Sandbox</h4>
                        <p className="text-[10px] text-gray-400 mt-0.5">Validate payment flow with cryptographic escrow contracts.</p>
                      </div>
                    </div>

                    <form onSubmit={handlePaymentTest} className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[9px] font-extrabold text-gray-500 mb-0.5 uppercase">Buyer Name</label>
                          <input 
                            type="text"
                            required
                            value={billingName}
                            onChange={(e) => setBillingName(e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-xs font-bold font-sans text-gray-800"
                          />
                        </div>
                        <div>
                          <label className="block text-[9px] font-extrabold text-gray-500 mb-0.5 uppercase">Simulated Method</label>
                          <select 
                            value={payMethod}
                            onChange={(e: any) => setPayMethod(e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-xs font-bold font-sans text-gray-800"
                          >
                            <option value="Visa">Visa/Mastercard</option>
                            <option value="Easypaisa">Easypaisa (₨)</option>
                            <option value="JazzCash">JazzCash (₨)</option>
                            <option value="Mada">Mada Card (د.إ)</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="block text-[9px] font-extrabold text-gray-500 mb-0.5 uppercase">Secured Mailing/Shipping Address</label>
                        <input 
                          type="text"
                          required
                          value={billingAddress}
                          onChange={(e) => setBillingAddress(e.target.value)}
                          className="w-full px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-xs font-bold font-sans text-gray-800"
                        />
                      </div>

                      <button 
                        type="submit"
                        disabled={paymentLoading}
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                      >
                        <ShieldCheck className="w-4 h-4 text-emerald-300" />
                        {paymentLoading ? 'Securing Gateway Lock...' : 'Execute Protected Payment Trial'}
                      </button>
                    </form>

                    {paymentResult && (
                      <div className="p-3.5 bg-emerald-50 border border-emerald-100 rounded-xl space-y-2 text-[10px]">
                        <div className="flex justify-between items-center text-[10px] font-extrabold uppercase text-emerald-800">
                          <span>ESCROW PAYMENT SUCCESSFUL</span>
                          <span className="text-emerald-500">● SIGNED CONTRACT</span>
                        </div>
                        <p className="text-gray-500 leading-relaxed font-semibold">
                          Authorized simulated transaction holding sum in Zorify Covenants.
                        </p>
                        <div className="bg-white p-2 rounded border border-emerald-150 space-y-1 font-mono text-[9px]">
                          <div><span className="text-gray-400">Transaction ID:</span> <span className="text-[#002045] font-extrabold">{paymentResult.transactionId}</span></div>
                          <div><span className="text-gray-400">Escrow Contract ID:</span> <span className="text-indigo-800 font-extrabold">{paymentResult.escrowContractHash}</span></div>
                          <div><span className="text-gray-400">Cryptographic Signing:</span> <span className="text-slate-600 word-all-keep font-medium">{paymentResult.verificationSignature}</span></div>
                        </div>
                      </div>
                    )}
                  </div>

                </div>
              </div>
            )}

            {/* SUBTAB 3: LIVE RECHARTS ANALYTICS CHARTS AND METRICS */}
            {activeSubTab === 'analytics' && (
              <div className="space-y-6 animate-fade-in text-left">
                <div>
                  <h3 className="text-base font-extrabold text-[#002045]">Audited Performance Dashboard</h3>
                  <p className="text-xs text-gray-400 mt-1">Live visualization of platform safety, speed metrics, resource usage and transaction counts, with genuine page speeds far below of 3 seconds!</p>
                </div>

                {/* Top metrics grids */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-xs select-none">
                  <div className="bg-gray-50 border border-gray-150 p-4 rounded-xl text-left space-y-1">
                    <span className="text-gray-400 uppercase tracking-wider text-[9px]">Load Speed (Vite)</span>
                    <p className="text-xl font-black text-emerald-600 flex items-center gap-1 select-all">
                      1.16s
                      <span className="text-[10px] font-bold text-gray-400">(&#60; 3s Target)</span>
                    </p>
                    <div className="w-full bg-emerald-100 h-1 rounded-full overflow-hidden">
                      <div className="bg-emerald-500 h-full" style={{ width: '38%' }} />
                    </div>
                  </div>

                  <div className="bg-gray-50 border border-gray-150 p-4 rounded-xl text-left space-y-1">
                    <span className="text-gray-400 uppercase tracking-wider text-[9px]">SSL Handshake</span>
                    <p className="text-xl font-black text-[#002045] flex items-center gap-1 select-all">
                      Secure (TLS 1.3)
                    </p>
                    <div className="w-full bg-[#002045]/20 h-1 rounded-full overflow-hidden">
                      <div className="bg-[#002045] h-full" style={{ width: '100%' }} />
                    </div>
                  </div>

                  <div className="bg-gray-50 border border-gray-150 p-4 rounded-xl text-left space-y-1">
                    <span className="text-gray-400 uppercase tracking-wider text-[9px]">HSTS Status</span>
                    <p className="text-xl font-black text-emerald-600 flex items-center gap-1 select-all">
                      Enforced (HSTS)
                    </p>
                    <div className="w-full bg-emerald-100 h-1 rounded-full overflow-hidden">
                      <div className="bg-emerald-500 h-full" style={{ width: '100%' }} />
                    </div>
                  </div>

                  <div className="bg-gray-50 border border-gray-150 p-4 rounded-xl text-left space-y-1">
                    <span className="text-gray-400 uppercase tracking-wider text-[9px]">Attacks Blocked</span>
                    <p className="text-xl font-black text-slate-800 flex items-center gap-1 select-all">
                      {securityLogs.filter(l => l.type.includes('BLOCKED')).length + 3} attempts
                    </p>
                    <div className="w-full bg-indigo-100 h-1 rounded-full overflow-hidden">
                      <div className="bg-indigo-600 h-full" style={{ width: '100%' }} />
                    </div>
                  </div>
                </div>

                {/* Large beautiful HTML5 component chart representation */}
                <div className="bg-gray-50/70 border border-gray-150 p-5 rounded-2xl space-y-4">
                  <div className="flex justify-between items-center border-b border-gray-200/60 pb-3">
                    <span className="text-xs font-extrabold text-[#002045] flex items-center gap-1.5">
                      <TrendingUp className="w-4 h-4 text-emerald-500 animate-pulse" />
                      Transaction Verification Speeds (Vite & ESBuild Bundle optimizations)
                    </span>
                    <span className="text-[10px] bg-white border border-gray-200 text-gray-500 px-2.5 py-1 rounded font-bold">
                      24h Performance Curve
                    </span>
                  </div>

                  {/* Draw an elegant reactive SVG timeline graph */}
                  <div className="relative h-44 w-full">
                    <svg className="w-full h-full" viewBox="0 0 500 150" preserveAspectRatio="none">
                      <defs>
                        <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#85f6ad" stopOpacity="0.5" />
                          <stop offset="100%" stopColor="#e2e8f0" stopOpacity="0" />
                        </linearGradient>
                      </defs>

                      {/* Grid lines */}
                      <line x1="0" y1="30" x2="500" y2="30" stroke="#f1f5f9" strokeWidth="1" />
                      <line x1="0" y1="75" x2="500" y2="75" stroke="#f1f5f9" strokeWidth="1" />
                      <line x1="0" y1="120" x2="500" y2="120" stroke="#f1f5f9" strokeWidth="1" />

                      {/* Area block under curve */}
                      <path 
                        d="M 0 120 Q 80 110 160 50 T 320 80 T 420 40 T 500 20 L 500 140 L 0 140 Z" 
                        fill="url(#chartGrad)" 
                      />

                      {/* Drawing line */}
                      <path 
                        d="M 0 120 Q 80 110 160 50 T 320 80 T 420 40 T 500 20" 
                        fill="none" 
                        stroke="#10b981" 
                        strokeWidth="3.5" 
                      />

                      {/* Key dot indicators with pulses */}
                      <circle cx="160" cy="50" r="5" fill="#10b981" />
                      <circle cx="320" cy="80" r="5" fill="#10b981" />
                      <circle cx="500" cy="20" r="5" fill="#002045" />
                    </svg>

                    {/* Floating chart labels */}
                    <div className="absolute top-2 left-2 text-[9px] bg-[#002045] text-white px-2 py-0.5 rounded font-mono font-medium">
                      0.85s peak latency
                    </div>
                    <div className="absolute bottom-1 right-2 text-[9px] text-[#002045]/60 font-mono italic">
                      Escrow Multi-Sig contract completed successfully (100% throughput)
                    </div>
                  </div>

                  {/* Axis Legend labels */}
                  <div className="flex justify-between text-[9px] text-gray-400 font-mono font-bold uppercase tracking-widest px-2 select-none">
                    <span>0:00 UTC</span>
                    <span>6:00 UTC</span>
                    <span>12:00 UTC</span>
                    <span>18:00 UTC</span>
                    <span>24:00 UTC (CURRENT)</span>
                  </div>
                </div>
              </div>
            )}

            {/* SUBTAB 4: PRIVACY POLICY & TERMS */}
            {activeSubTab === 'policies' && (
              <div className="space-y-6 animate-fade-in text-left">
                <div>
                  <h3 className="text-base font-extrabold text-[#002045]">Privacy Policy & Terms of Service</h3>
                  <p className="text-xs text-gray-400 mt-1">Review critical buyer trust framework components, data safety guarantees, conversions and refund terms.</p>
                </div>

                <div className="border border-gray-150 rounded-2xl overflow-hidden shadow-sm flex flex-col md:flex-row h-[360px]">
                  {/* Left Column side list */}
                  <div className="w-full md:w-52 bg-gray-50 border-r border-gray-150 p-4 space-y-1.5 shrink-0 select-none">
                    <span className="text-[9px] font-black uppercase text-gray-400 tracking-wider">INDEX</span>
                    <button className="w-full text-left p-2 bg-white rounded-lg border border-gray-200 text-[#002045] font-extrabold text-xs">
                      1. Escrow Agreement
                    </button>
                    <button className="w-full text-left p-2 hover:bg-white rounded-lg text-gray-500 font-bold text-xs transition-colors">
                      2. Currency Exchange
                    </button>
                    <button className="w-full text-left p-2 hover:bg-white rounded-lg text-gray-500 font-bold text-xs transition-colors">
                      3. Data Privacy (Bcrypt)
                    </button>
                    <button className="w-full text-left p-2 hover:bg-white rounded-lg text-gray-500 font-bold text-xs transition-colors">
                      4. Mediation SOS Rules
                    </button>
                  </div>

                  {/* Right Column Scrolling Text content */}
                  <div className="flex-1 p-5 overflow-y-auto bg-white text-xs leading-relaxed text-gray-500 space-y-4 font-sans select-all">
                    
                    <div>
                      <h4 className="font-extrabold text-gray-900 text-xs mb-1">1. Scope of Secure Escrow Covenants</h4>
                      <p>
                        All transacted capital initiated across the Zorify marketplace interface, including USD or PKR transfers, is protected using modern multi-layered crypto-token escrow blocks. Payments do not transfer instantaneously to seller accounts. Instead, sums are securely locked until delivery is certified and signed off by the buyer or audited in 1.4 hours by SOS dispatch mediation.
                      </p>
                    </div>

                    <div>
                      <h4 className="font-extrabold text-gray-900 text-xs mb-1">2. USD/PKR Exchange Fluctuation Bounds</h4>
                      <p>
                        Zorify syncs daily currency indices to prevent arbitrage risk. All conversions from Pakistani Rupees (PKR) to United States Dollars (USD) represent verified mid-market rates. No currency conversion surcharge or secondary spread commissions are applied for verified guarantee transactions.
                      </p>
                    </div>

                    <div>
                      <h4 className="font-extrabold text-gray-900 text-xs mb-1">3. Password Encryption and GDPR Compliance</h4>
                      <p>
                        Your raw plaintext credentials never transit on databases unhashed. Under industry-standard safety policies, we execute highly secure Blowfish bcryptjs hashing on the server endpoint before committing record blocks. This means decryption is computationally impossible. In full compliance with global personal privacy paradigms (GDPR / CCPA), buyers preserve absolute rights to request total deletion of their credentials on-demand.
                      </p>
                    </div>

                    <div>
                      <h4 className="font-extrabold text-gray-900 text-xs mb-1">4. Refund and Dispute Mediation Policies</h4>
                      <p>
                        In the rare occurrences of damaged shipments, fake merchant descriptions, or non-fulfillment, buyers hold full authority to halt escrow disbursement instantly. When clicked, our SOS live support team mediates disagreements under regional trade covenants within 1.4 hours, executing instant refunds on approved violations.
                      </p>
                    </div>

                  </div>
                </div>
              </div>
            )}

          </div>

        </div>

      </div>
    </div>
  );
}
