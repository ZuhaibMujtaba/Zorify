import React, { useState } from 'react';
import { ShoppingCart, Globe, Search, RefreshCw, Sparkles, HelpCircle, ShieldCheck, Bell } from 'lucide-react';

interface HeaderProps {
  cartCount: number;
  onCartOpen: () => void;
  currency: 'USD' | 'PKR';
  setCurrency: (c: 'USD' | 'PKR') => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onSearch: (query: string) => void;
  isSearching: boolean;
  onShowHowItWorks: () => void;
  onShowSOS: () => void;
  onShowLaunchControl: () => void;
  onShowNotifications: () => void;
}

export default function Header({
  cartCount,
  onCartOpen,
  currency,
  setCurrency,
  searchQuery,
  setSearchQuery,
  onSearch,
  isSearching,
  onShowHowItWorks,
  onShowSOS,
  onShowLaunchControl,
  onShowNotifications
}: HeaderProps) {
  const [showCurrencyDropdown, setShowCurrencyDropdown] = useState(false);

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      onSearch(searchQuery);
    }
  };

  return (
    <header className="sticky top-0 w-full z-40 bg-white border-b border-gray-200/90 shadow-sm transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Logo and Main Nav */}
        <div className="flex items-center gap-8 justify-between w-full md:w-auto">
          <div className="flex items-center gap-2 cursor-pointer group" onClick={() => { setSearchQuery(''); onSearch(''); }}>
            <span className="text-3xl font-extrabold tracking-tight text-[#002045] font-sans flex items-center gap-1.5">
              Zorify
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse mt-3" />
            </span>
          </div>
          
          <nav className="hidden lg:flex items-center gap-6">
            <span 
              onClick={() => {
                document.getElementById('categories-explore-section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
              }}
              className="text-sm font-semibold text-[#002045] border-b-2 border-[#002045] pb-0.5 cursor-pointer hover:opacity-80 transition-opacity"
            >
              Categories
            </span>
            <span 
              onClick={onShowHowItWorks}
              className="text-sm font-medium text-gray-500 hover:text-[#002045] hover:bg-gray-50 px-2 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              Safe Buy
            </span>
            <span 
              onClick={onShowSOS}
              className="text-sm font-medium text-gray-500 hover:text-[#002045] hover:bg-gray-50 px-2 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1"
            >
              <HelpCircle className="w-4 h-4 text-sky-500" />
              SOS Support
            </span>
            <span 
              onClick={onShowLaunchControl}
              className="text-sm font-semibold text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 px-2.5 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 bg-emerald-50/50 border border-emerald-500/20"
              id="header-launch-control-link"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-600 animate-pulse" />
              Launch Desk
            </span>
          </nav>
        </div>

        {/* AI-Powered Search Bar */}
        <div className="flex-1 max-w-xl w-full">
          <div className="relative group">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-[#002045] transition-colors">
              {isSearching ? (
                <RefreshCw className="w-5 h-5 animate-spin text-[#002045]" />
              ) : (
                <Search className="w-5 h-5 text-gray-400" />
              )}
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleKeyPress}
              className="w-full pl-11 pr-32 py-2.5 bg-gray-50 hover:bg-gray-100/70 focus:bg-white border border-gray-200 focus:border-[#002045] focus:outline-none focus:ring-4 focus:ring-sky-100 rounded-xl transition-all text-sm font-sans placeholder-gray-400 text-gray-900 shadow-inner"
              placeholder="Query our assistant... (e.g. 'headphones for work')"
            />
            <button
              onClick={() => onSearch(searchQuery)}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-[#002045] text-white hover:bg-[#003060] transition-colors px-3 py-1.5 rounded-lg text-xs font-bold font-sans flex items-center gap-1 cursor-pointer whitespace-nowrap"
            >
              <Sparkles className="w-3 h-3 text-emerald-400" />
              AI Search
            </button>
          </div>
        </div>

        {/* Action Widgets */}
        <div className="flex items-center gap-3 justify-between w-full md:w-auto md:justify-end">
          
          {/* Global Currency Conversion Toggle */}
          <div className="relative">
            <button
              onClick={() => setShowCurrencyDropdown(!showCurrencyDropdown)}
              className="flex items-center gap-1.5 text-gray-600 hover:text-[#002045] px-2.5 py-1.5 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors text-xs font-semibold"
            >
              <Globe className="w-4 h-4 text-gray-400" />
              <span>Currency: <strong className="text-emerald-600">{currency}</strong></span>
            </button>

            {showCurrencyDropdown && (
              <div className="absolute right-0 mt-1.5 w-32 bg-white rounded-xl shadow-lg border border-gray-100 py-1.5 z-50">
                <button
                  onClick={() => { setCurrency('PKR'); setShowCurrencyDropdown(false); }}
                  className={`w-full text-left px-3 py-1.5 text-xs font-semibold flex justify-between items-center ${currency === 'PKR' ? 'text-emerald-600 bg-emerald-50' : 'text-gray-700 hover:bg-gray-50'}`}
                >
                  PKR (₨)
                  {currency === 'PKR' && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />}
                </button>
                <button
                  onClick={() => { setCurrency('USD'); setShowCurrencyDropdown(false); }}
                  className={`w-full text-left px-3 py-1.5 text-xs font-semibold flex justify-between items-center ${currency === 'USD' ? 'text-emerald-600 bg-emerald-50' : 'text-gray-700 hover:bg-gray-50'}`}
                >
                  USD ($)
                  {currency === 'USD' && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />}
                </button>
              </div>
            )}
          </div>

          <button 
            onClick={onShowLaunchControl}
            className="hidden md:block text-[#002045] hover:bg-gray-50 transition-colors px-3 py-1.5 rounded-lg text-sm font-semibold font-sans cursor-pointer"
          >
            Sign In / Secure Desk
          </button>

          {/* Email Alert Notification Button */}
          <button
            onClick={onShowNotifications}
            className="flex items-center gap-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 px-3 py-2.5 rounded-xl text-sm font-bold shadow-sm hover:shadow transition-all relative border border-amber-200 cursor-pointer"
            id="notification-subscribe-btn"
            title="Subscribe to Email Alerts"
          >
            <Bell className="w-4 h-4 text-amber-600 animate-bounce" />
            <span className="hidden sm:inline text-xs">Alerts</span>
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full animate-ping" />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-red-500 rounded-full" />
          </button>

          {/* Interactive Cart Button */}
          <button
            onClick={onCartOpen}
            className="flex items-center gap-2 bg-[#002045] hover:bg-[#003060] text-white px-4 py-2.5 rounded-xl text-sm font-bold shadow-md hover:shadow-lg transition-all relative"
            id="cart-trigger-btn"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>Cart</span>
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-emerald-500 text-white rounded-full text-[10px] font-extrabold flex items-center justify-center border-2 border-white animate-bounce">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
