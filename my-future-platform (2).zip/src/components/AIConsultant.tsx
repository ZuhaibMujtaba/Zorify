import React, { useState } from 'react';
import { Sparkles, MessageCircle, RefreshCw, ChevronRight, HelpCircle, ArrowRight, ShieldAlert } from 'lucide-react';
import { AISearchResult, Product } from '../types';
import { PRODUCTS } from '../data';

interface AIConsultantProps {
  onHighlightProducts: (productIds: string[]) => void;
  currency: 'USD' | 'PKR';
  onQuickView: (product: Product) => void;
  products: Product[];
}

export default function AIConsultant({
  onHighlightProducts,
  currency,
  onQuickView,
  products
}: AIConsultantProps) {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AISearchResult | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  const PRESETS = [
    { label: 'Recommend high-end noise-cancelling headphones', q: 'Find me high-end wireless headphones with strong noise canceling' },
    { label: 'Show me premium organic skincare kits', q: 'Which skincare set is organic and contains Vitamin C?' },
    { label: 'Help me find a gift for a baby nursery', q: 'What products are recommended for keeping an eye on a baby or nursery?' },
    { label: 'Suggest a smart thermostat with Matter support', q: 'Do you have a thermostat with active Matter support?' }
  ];

  const handleConsult = async (queryString: string) => {
    if (!queryString.trim()) return;
    setQuery(queryString);
    setLoading(true);
    setErrorMsg('');
    setResult(null);

    try {
      const response = await fetch('/api/gemini/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ query: queryString })
      });

      if (!response.ok) {
        throw new Error('Our AI model is currently training. Please check your credentials or retry.');
      }

      const data = await response.json();
      setResult(data);
      if (data.matchedProductIds && data.matchedProductIds.length > 0) {
        onHighlightProducts(data.matchedProductIds);
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Connecting with Zorify AI fails. Verify server-side GEMINI_API_KEY settings.');
    } finally {
      setLoading(false);
    }
  };

  const getMatchedProducts = () => {
    if (!result || !result.matchedProductIds) return [];
    return products.filter(p => result.matchedProductIds.includes(p.id));
  };

  const formatPrice = (p: Product) => {
    const symbol = currency === 'USD' ? '$' : 'PKR';
    const val = currency === 'USD' ? p.priceUSD : p.pricePKR;
    return currency === 'USD' ? `${symbol}${val.toLocaleString()}` : `${symbol} ${val.toLocaleString()}`;
  };

  return (
    <div className="bg-gradient-to-br from-indigo-900/90 to-[#002045] rounded-[2rem] p-6 lg:p-8 text-white relative overflow-hidden shadow-2xl">
      <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500 opacity-5 rounded-full blur-3xl -mr-32 -mt-32" />
      <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-indigo-500 opacity-5 rounded-full blur-3xl" />

      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Explainer and Presets */}
        <div className="lg:col-span-5 space-y-5 text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 rounded-full border border-white/20">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-[#85f6ad]">Zorify AI Engine</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight leading-tight">
            Ask Zorify AI <br className="hidden sm:inline" />
            Personal Shopping Advisor
          </h2>
          
          <p className="text-gray-300 text-xs leading-relaxed max-w-sm">
            Tired of scouring countless product listings? Tell Zorify AI what you seek, and we will cross-reference seller metrics to recommend optimal purchases.
          </p>

          <hr className="border-white/10" />

          {/* Preset Buttons */}
          <div className="space-y-2">
            <h3 className="text-[10px] font-extrabold text-gray-400 uppercase tracking-widest">SUGGESTED AI INQUIRIES</h3>
            <div className="flex flex-col gap-2.5">
              {PRESETS.map((preset, index) => (
                <button
                  key={index}
                  onClick={() => handleConsult(preset.q)}
                  className="w-full text-left bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 p-2.5 rounded-xl text-xs font-semibold text-gray-200 hover:text-white transition-all transition-colors flex items-center justify-between cursor-pointer group"
                >
                  <span className="truncate pr-4">{preset.label}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-gray-400 group-hover:text-emerald-300 transition-colors shrink-0" />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Dynamic Input & Results Panel */}
        <div className="lg:col-span-7 bg-white/5 border border-white/10 backdrop-blur-md rounded-2xl p-5 sm:p-6 space-y-5 min-h-[300px] flex flex-col justify-between">
          
          {/* Main Advisor Feed View */}
          <div className="flex-1 space-y-4">
            
            {/* Initial Placeholder View */}
            {!loading && !result && !errorMsg && (
              <div className="h-full flex flex-col items-center justify-center py-10 text-center space-y-3.5 text-gray-300">
                <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center">
                  <MessageCircle className="w-6 h-6 text-emerald-400" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white mb-1">Begin your Personalized Consultation</h4>
                  <p className="text-[11px] text-gray-400 max-w-sm">
                    Enter any sentence or click one of our predefined assistant prompts. Zorify AI reads the ledger in real-time.
                  </p>
                </div>
              </div>
            )}

            {/* Error view */}
            {errorMsg && (
              <div className="bg-rose-500/10 border border-rose-500/20 px-4 py-3.5 rounded-xl text-xs text-rose-300 flex items-start gap-2.5">
                <ShieldAlert className="w-4 h-4 text-rose-400 mt-0.5 shrink-0" />
                <div>
                  <strong>Advisor Link Terminated:</strong> {errorMsg}
                </div>
              </div>
            )}

            {/* Loading Advisor View */}
            {loading && (
              <div className="h-full flex flex-col items-center justify-center py-14 text-center space-y-3.5 text-gray-200">
                <RefreshCw className="w-8 h-8 text-emerald-400 animate-spin" />
                <div>
                  <h4 className="text-xs font-bold text-white mb-0.5">Zorify Ledger Audit in progress...</h4>
                  <p className="text-[10px] text-gray-400">Comparing seller ratings, cross-referencing prices, and loading options.</p>
                </div>
              </div>
            )}

            {/* Success Result view */}
            {!loading && result && (
              <div className="space-y-4 text-xs animate-fade-in text-left">
                
                {/* Advisor conversational explanation */}
                <div className="bg-white/5 border border-white/10 p-4 rounded-xl space-y-2">
                  <div className="flex justify-between items-center bg-white/10 px-2 py-1 rounded text-[10px] text-emerald-400 font-bold self-start max-w-max uppercase tracking-wider">
                    RECOMMENDATION ANALYSIS
                  </div>
                  <p className="text-[11.5px] leading-relaxed font-sans text-gray-100">
                    {result.reply}
                  </p>
                  {result.recommendationExplanation && (
                    <p className="text-[10.5px] text-emerald-300 font-medium italic border-t border-white/5 pt-1.5 mt-2">
                      Zorify AI Conclusion: {result.recommendationExplanation}
                    </p>
                  )}
                </div>

                {/* Sub-Matched Products Horizontal Cards */}
                {getMatchedProducts().length > 0 && (
                  <div className="space-y-2.5">
                    <h4 className="text-[10px] font-bold uppercase text-gray-400 tracking-wider">AI Recommended Products Catalogue</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {getMatchedProducts().map((product) => (
                        <div 
                          key={product.id}
                          className="bg-white p-3 rounded-xl flex gap-3 text-gray-900 border border-gray-100 shadow-sm hover:border-emerald-500 transition-all cursor-pointer group"
                          onClick={() => onQuickView(product)}
                        >
                          <img 
                            src={product.image} 
                            alt={product.title} 
                            className="w-12 h-12 rounded-lg object-cover border border-gray-100"
                            referrerPolicy="no-referrer"
                          />
                          <div className="flex-1 min-w-0 flex flex-col justify-between">
                            <div>
                              <h5 className="text-[10.5px] font-extrabold truncate group-hover:text-emerald-600 transition-colors">{product.title}</h5>
                              <p className="text-[9.5px] text-gray-400 font-medium">{product.category}</p>
                            </div>
                            <div className="flex justify-between items-center text-[10px] mt-1.5">
                              <span className="font-extrabold text-emerald-700">{formatPrice(product)}</span>
                              <span className="text-[9px] text-[#002045] font-bold flex items-center gap-0.5">
                                View
                                <ChevronRight className="w-3.5 h-3.5" />
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

              </div>
            )}
          </div>

          {/* Chat Form Widget Input */}
          <div className="pt-4 border-t border-white/10">
            <div className="relative flex items-center bg-white/10 rounded-xl border border-white/10 focus-within:ring-2 focus-within:ring-emerald-400 transition-all">
              <input
                type="text"
                placeholder="Ask model... (e.g. 'find organic body rituals')"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleConsult(query)}
                className="w-full bg-transparent pl-4 pr-12 py-3 rounded-xl text-xs placeholder-gray-400 text-white focus:outline-none focus:ring-0 focus:border-transparent"
              />
              <button
                onClick={() => handleConsult(query)}
                disabled={loading}
                className="absolute right-2 p-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 font-bold transition-colors shadow-md cursor-pointer disabled:bg-emerald-600/50"
              >
                <Sparkles className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
