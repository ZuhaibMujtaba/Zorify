import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  ShoppingBag, 
  User, 
  TrendingUp, 
  LogOut, 
  Plus, 
  Truck, 
  CheckCircle2, 
  Clock, 
  ArrowRight, 
  Search, 
  Mail, 
  FileText, 
  Database, 
  RefreshCw, 
  Zap, 
  Sparkles, 
  Trash2, 
  Heart,
  ChevronRight,
  Info
} from 'lucide-react';
import { Product } from '../types';

interface DashboardPortalProps {
  currentUser: { id: string; username: string; role: 'buyer' | 'seller' | 'admin'; sessionToken: string };
  onLogout: () => void;
  currency: 'USD' | 'PKR';
  products: Product[];
  onRefreshProducts: () => void;
  triggerToast: (msg: string) => void;
}

export default function DashboardPortal({
  currentUser,
  onLogout,
  currency,
  products,
  onRefreshProducts,
  triggerToast
}: DashboardPortalProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'inventory' | 'emails' | 'addresses'>('overview');
  const [orders, setOrders] = useState<any[]>([]);
  const [emails, setEmails] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [syncingHHC, setSyncingHHC] = useState(false);

  // New product form (Seller tab)
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<'Fashion' | 'Beauty' | 'Electronics' | 'Home' | 'Baby' | 'Books'>('Electronics');
  const [newPricePKR, setNewPricePKR] = useState('');
  const [newImage, setNewImage] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newSpecs, setNewSpecs] = useState('Brand: Zorify, Material: Premium, Warranty: 1 Year');

  // Address form (Buyer tab)
  const [shippingAddress, setShippingAddress] = useState(() => {
    return localStorage.getItem(`address-${currentUser.username}`) || 'Model Town, Block C, Lahore, Pakistan';
  });

  // Track currently selected order for live timeline tracking
  const [selectedOrder, setSelectedOrder] = useState<any>(null);

  // Fetch orders and email logs
  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch orders
      const orderRes = await fetch(`/api/orders?token=${currentUser.sessionToken}`);
      if (orderRes.ok) {
        const orderData = await orderRes.json();
        setOrders(orderData);
        if (orderData.length > 0 && !selectedOrder) {
          setSelectedOrder(orderData[0]);
        }
      }

      // Fetch emails (Admin only)
      if (currentUser.role === 'admin') {
        const emailRes = await fetch(`/api/admin/emails?token=${currentUser.sessionToken}`);
        if (emailRes.ok) {
          const emailData = await emailRes.json();
          setEmails(emailData);
        }
      }
    } catch (e) {
      console.error('Error loading dashboard data:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [currentUser]);

  // Sync products from HHC Dropshipping (Admin / Seller)
  const handleHHCSync = async () => {
    setSyncingHHC(true);
    try {
      const res = await fetch('/api/dropship/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: currentUser.sessionToken })
      });
      const data = await res.json();
      if (res.ok) {
        triggerToast(`Successfully synced ${data.count} trending products with exactly 15% profit margin!`);
        onRefreshProducts();
        fetchData();
      } else {
        triggerToast(data.error || 'Dropship sync failed.');
      }
    } catch (e) {
      triggerToast('Error connecting to HHC servers.');
    } finally {
      setSyncingHHC(false);
    }
  };

  // Add new custom product (Seller portal)
  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newPricePKR || !newImage) {
      triggerToast('Please provide a title, price, and image URL.');
      return;
    }
    const pricePKRNum = parseFloat(newPricePKR);
    if (isNaN(pricePKRNum) || pricePKRNum <= 0) {
      triggerToast('Please enter a valid numeric price.');
      return;
    }

    try {
      const response = await fetch('/api/seller/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: currentUser.sessionToken,
          title: newTitle,
          category: newCategory,
          pricePKR: pricePKRNum,
          priceUSD: Math.round(pricePKRNum / 278), // Simulated exchange rate conversion
          image: newImage,
          description: newDescription || 'Premium verified product listed via Zorify vendor network.',
          specificationsStr: newSpecs
        })
      });

      const data = await response.json();
      if (response.ok) {
        triggerToast(`Successfully listed "${newTitle}" in our catalog!`);
        onRefreshProducts();
        setNewTitle('');
        setNewPricePKR('');
        setNewImage('');
        setNewDescription('');
        setActiveTab('overview');
      } else {
        triggerToast(data.error || 'Failed to list product.');
      }
    } catch (e) {
      triggerToast('Network error listing product.');
    }
  };

  // Update order status (Admin / Seller)
  const handleUpdateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: currentUser.sessionToken, status: newStatus })
      });
      const data = await res.json();
      if (res.ok) {
        triggerToast(`Order status updated to ${newStatus} successfully!`);
        setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus, trackingHistory: data.trackingHistory } : o));
        if (selectedOrder && selectedOrder.id === orderId) {
          setSelectedOrder(prev => prev ? { ...prev, status: newStatus, trackingHistory: data.trackingHistory } : null);
        }
      } else {
        triggerToast(data.error || 'Failed to update order status.');
      }
    } catch (e) {
      triggerToast('Error updating order status.');
    }
  };

  // Save shipping address (Buyer)
  const handleSaveAddress = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem(`address-${currentUser.username}`, shippingAddress);
    triggerToast('Shipping address saved securely!');
  };

  const getPriceSymbol = () => (currency === 'USD' ? '$' : 'PKR');

  const formatPrice = (pkr: number, usd: number) => {
    return currency === 'USD' ? `$${usd}` : `PKR ${pkr.toLocaleString()}`;
  };

  return (
    <div className="bg-white border border-gray-150 rounded-3xl overflow-hidden shadow-xl max-w-6xl mx-auto my-8">
      
      {/* Dashboard Top Navigation bar */}
      <div className="bg-[#002045] text-white p-6 flex flex-col md:flex-row items-center justify-between gap-4 border-b border-gray-800">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center border border-white/20">
            <User className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-extrabold tracking-tight">Welcome, {currentUser.username}</h2>
              <span className={`text-[9px] font-extrabold uppercase px-2.5 py-0.5 rounded-full tracking-wider border ${
                currentUser.role === 'admin' 
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/30' 
                  : currentUser.role === 'seller'
                    ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
                    : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
              }`}>
                {currentUser.role} Control Portal
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">Secure Escrow Covenant Verification Active</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-white/5 border border-white/15 px-4 py-2 rounded-xl text-center text-xs">
            <span className="text-slate-400">Account Coins: </span>
            <strong className="text-emerald-400 font-bold font-mono">150 ZOR</strong>
          </div>
          <button 
            onClick={onLogout}
            className="bg-white/10 hover:bg-rose-600 hover:text-white px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-white/10"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </button>
        </div>
      </div>

      {/* Main Layout Grid (Tabs Sidebar + Content Area) */}
      <div className="grid grid-cols-1 md:grid-cols-4 min-h-[500px]">
        
        {/* Sidebar Tabs selectors */}
        <div className="bg-gray-50 p-5 border-r border-gray-150 flex flex-col justify-between gap-6">
          <div className="space-y-1.5">
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest pl-2 mb-2">OPERATIONS</p>
            
            <button 
              onClick={() => setActiveTab('overview')}
              className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2.5 transition-all cursor-pointer ${activeTab === 'overview' ? 'bg-[#002045] text-white shadow-md' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
            >
              <TrendingUp className="w-4 h-4" />
              Portal Overview
            </button>

            <button 
              onClick={() => setActiveTab('orders')}
              className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2.5 transition-all cursor-pointer ${activeTab === 'orders' ? 'bg-[#002045] text-white shadow-md' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
            >
              <Truck className="w-4 h-4" />
              {currentUser.role === 'buyer' ? 'Order History & Live Tracking' : 'Manage Client Orders'}
              {orders.length > 0 && (
                <span className="ml-auto bg-emerald-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full">
                  {orders.length}
                </span>
              )}
            </button>

            {currentUser.role !== 'buyer' && (
              <button 
                onClick={() => setActiveTab('inventory')}
                className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2.5 transition-all cursor-pointer ${activeTab === 'inventory' ? 'bg-[#002045] text-white shadow-md' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
              >
                <Plus className="w-4 h-4" />
                {currentUser.role === 'admin' ? 'HHC Sync & Inventory' : 'Manage My Listings'}
              </button>
            )}

            {currentUser.role === 'admin' && (
              <button 
                onClick={() => setActiveTab('emails')}
                className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2.5 transition-all cursor-pointer ${activeTab === 'emails' ? 'bg-[#002045] text-white shadow-md' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
              >
                <Mail className="w-4 h-4" />
                Admin Email Logs
                {emails.length > 0 && (
                  <span className="ml-auto bg-indigo-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full animate-pulse">
                    {emails.length}
                  </span>
                )}
              </button>
            )}

            {currentUser.role === 'buyer' && (
              <button 
                onClick={() => setActiveTab('addresses')}
                className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2.5 transition-all cursor-pointer ${activeTab === 'addresses' ? 'bg-[#002045] text-white shadow-md' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
              >
                <User className="w-4 h-4" />
                Delivery Address Book
              </button>
            )}
          </div>

          {/* Quick Help box */}
          <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-2xl">
            <div className="flex items-center gap-2 text-emerald-800 font-extrabold text-xs">
              <ShieldCheck className="w-4 h-4" />
              Secure Protocol
            </div>
            <p className="text-[10px] text-emerald-700 leading-relaxed mt-1">
              All transactions are fully governed by cryptographic escrow protection keys to eliminate double-spending or counterfeit deliveries.
            </p>
          </div>
        </div>

        {/* Primary Content Window */}
        <div className="col-span-3 p-6 sm:p-8 overflow-y-auto">
          
          {loading && (
            <div className="flex flex-col items-center justify-center py-20 text-gray-400 space-y-2">
              <RefreshCw className="w-8 h-8 animate-spin text-[#002045]" />
              <p className="text-xs font-bold">Synchronizing system parameters...</p>
            </div>
          )}

          {!loading && (
            <>
              {/* TAB 1: OVERVIEW */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  
                  {/* Dashboard Header summary banner */}
                  <div className="border-b border-gray-100 pb-5">
                    <h3 className="text-base font-extrabold text-gray-900">
                      {currentUser.role === 'admin' && 'Owner Control Room'}
                      {currentUser.role === 'seller' && 'Vendor Dashboard Portal'}
                      {currentUser.role === 'buyer' && 'Customer Safe Buy Space'}
                    </h3>
                    <p className="text-xs text-gray-400 mt-0.5">Real-time telemetry and state monitoring of Zorify Escrow network.</p>
                  </div>

                  {/* Metrics Row */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                    
                    <div className="bg-gray-50 border border-gray-100 p-4 rounded-2xl text-left space-y-1">
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider">
                        {currentUser.role === 'buyer' ? 'MY PLACED ORDERS' : 'TOTAL REVENUE'}
                      </span>
                      <p className="text-xl font-extrabold text-[#002045]">
                        {currentUser.role === 'buyer' 
                          ? `${orders.length} Orders` 
                          : formatPrice(
                              orders.reduce((acc, o) => acc + o.totalCost, 0),
                              Math.round(orders.reduce((acc, o) => acc + o.totalCost, 0) / 278)
                            )
                        }
                      </p>
                      <span className="text-[9px] text-emerald-600 font-extrabold">● ESCROW ACTIVE</span>
                    </div>

                    <div className="bg-gray-50 border border-gray-100 p-4 rounded-2xl text-left space-y-1">
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider">
                        PLATFORM ACTIVE ITEMS
                      </span>
                      <p className="text-xl font-extrabold text-emerald-600">{products.length} Products</p>
                      <span className="text-[9px] text-indigo-600 font-extrabold">
                        {products.filter(p => p.id.startsWith('hhc-')).length} Dropshipped
                      </span>
                    </div>

                    <div className="bg-gray-50 border border-gray-100 p-4 rounded-2xl text-left space-y-1">
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider">
                        SECURITY TELEMETRY
                      </span>
                      <p className="text-xl font-extrabold text-sky-600">99.8% Trust Score</p>
                      <span className="text-[9px] text-gray-400">Zero disputes logged today</span>
                    </div>

                  </div>

                  {/* Role specific custom layouts on overview tab */}
                  {currentUser.role === 'admin' && (
                    <div className="bg-indigo-50/50 border border-indigo-100 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
                      <div className="space-y-1 text-left">
                        <h4 className="text-xs font-bold text-indigo-900 flex items-center gap-1.5">
                          <Zap className="w-4 h-4 text-indigo-500 animate-bounce" />
                          HHC Dropshipping Integration (Pakistan Market)
                        </h4>
                        <p className="text-[11px] text-indigo-700 leading-relaxed max-w-lg">
                          Pull trending wholesale products from HHC Dropshipping database dynamically. The system will automatically compute the correct selling price using our <strong>exact 15% profit margin formula</strong> and upload them instantly into the public Zorify catalog!
                        </p>
                      </div>

                      <button
                        onClick={handleHHCSync}
                        disabled={syncingHHC}
                        className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white px-5 py-2.5 rounded-xl font-bold text-xs shrink-0 flex items-center gap-2 transition-all cursor-pointer shadow-md"
                      >
                        {syncingHHC ? (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                            Syncing database...
                          </>
                        ) : (
                          <>
                            <RefreshCw className="w-3.5 h-3.5" />
                            Run HHC Dropship Sync
                          </>
                        )}
                      </button>
                    </div>
                  )}

                  {currentUser.role === 'buyer' && orders.length > 0 && selectedOrder && (
                    <div className="bg-emerald-50/40 border border-emerald-100 rounded-3xl p-6 text-left space-y-5">
                      <div className="flex justify-between items-center border-b border-emerald-100/60 pb-3">
                        <h4 className="font-extrabold text-[#002045] text-xs">
                          Live Order Tracking Status: <span className="font-mono text-emerald-600">#{selectedOrder.id}</span>
                        </h4>
                        <span className="text-[10px] text-gray-400">Placed on: {new Date(selectedOrder.createdAt).toLocaleDateString()}</span>
                      </div>

                      {/* Timeline graphic representation */}
                      <div className="relative flex flex-col sm:flex-row justify-between items-center gap-6 py-4">
                        {/* Timeline background connectors bar */}
                        <div className="absolute left-[20px] top-[24px] bottom-[24px] sm:left-4 sm:right-4 sm:top-5 sm:bottom-auto h-full w-[2px] sm:h-[3px] sm:w-full bg-gray-200 -z-10" />

                        {/* Step 1: Placed */}
                        <div className="flex sm:flex-col items-center gap-3 sm:gap-2 text-center w-full sm:w-1/4">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${
                            selectedOrder.status === 'Placed' || selectedOrder.status === 'Processing' || selectedOrder.status === 'Shipped' || selectedOrder.status === 'Delivered'
                              ? 'bg-emerald-500 border-emerald-600 text-white shadow-md'
                              : 'bg-white border-gray-300 text-gray-400'
                          }`}>
                            <CheckCircle2 className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-[11px] font-bold text-gray-900">Order Placed</p>
                            <p className="text-[9px] text-gray-400 mt-0.5">Escrow payment locked</p>
                          </div>
                        </div>

                        {/* Step 2: Processing */}
                        <div className="flex sm:flex-col items-center gap-3 sm:gap-2 text-center w-full sm:w-1/4">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${
                            selectedOrder.status === 'Processing' || selectedOrder.status === 'Shipped' || selectedOrder.status === 'Delivered'
                              ? 'bg-emerald-500 border-emerald-600 text-white shadow-md animate-pulse'
                              : 'bg-white border-gray-300 text-gray-400'
                          }`}>
                            <Clock className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-[11px] font-bold text-gray-900">Processing</p>
                            <p className="text-[9px] text-gray-400 mt-0.5">Supplier preparing cargo</p>
                          </div>
                        </div>

                        {/* Step 3: Shipped */}
                        <div className="flex sm:flex-col items-center gap-3 sm:gap-2 text-center w-full sm:w-1/4">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${
                            selectedOrder.status === 'Shipped' || selectedOrder.status === 'Delivered'
                              ? 'bg-emerald-500 border-emerald-600 text-white shadow-md'
                              : 'bg-white border-gray-300 text-gray-400'
                          }`}>
                            <Truck className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-[11px] font-bold text-gray-900">Shipped Out</p>
                            <p className="text-[9px] text-gray-400 mt-0.5">Tracking code dispatched</p>
                          </div>
                        </div>

                        {/* Step 4: Delivered */}
                        <div className="flex sm:flex-col items-center gap-3 sm:gap-2 text-center w-full sm:w-1/4">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${
                            selectedOrder.status === 'Delivered'
                              ? 'bg-emerald-500 border-emerald-600 text-white shadow-md'
                              : 'bg-white border-gray-300 text-gray-400'
                          }`}>
                            <ShieldCheck className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-[11px] font-bold text-gray-900">Delivered Safely</p>
                            <p className="text-[9px] text-gray-400 mt-0.5">Escrow released to vendor</p>
                          </div>
                        </div>

                      </div>
                    </div>
                  )}

                  {/* Platform notice cards */}
                  <div className="bg-gray-50 rounded-2xl p-5 text-left border border-gray-100 flex items-start gap-4">
                    <Info className="w-5 h-5 text-[#002045] mt-0.5 shrink-0" />
                    <div>
                      <h4 className="text-xs font-bold text-[#002045]">Aesthetic & Trust Protocol Compliance notice</h4>
                      <p className="text-[11px] text-gray-500 leading-relaxed mt-1">
                        Zorify strictly regulates the listing of products and settlement of escrow agreements. Merchants attempting to ship counterfeit goods or list duplicate inventories face immediate account liquidation, forfeiture of security deposits, and blacklisting of routing gateways.
                      </p>
                    </div>
                  </div>

                </div>
              )}

              {/* TAB 2: MANAGE ORDERS */}
              {activeTab === 'orders' && (
                <div className="space-y-6">
                  <div className="border-b border-gray-100 pb-5">
                    <h3 className="text-base font-extrabold text-gray-900">
                      {currentUser.role === 'buyer' ? 'My Order History' : 'Client Orders & Escrow Control Desk'}
                    </h3>
                    <p className="text-xs text-gray-400 mt-0.5">
                      {currentUser.role === 'buyer' 
                        ? 'View order receipts, live logistics progression, and delivery tracking information.' 
                        : 'Review client escrow locks, verify logistics signatures, and advance tracking status variables.'}
                    </p>
                  </div>

                  {orders.length === 0 ? (
                    <div className="text-center py-20 text-gray-400 space-y-4">
                      <ShoppingBag className="w-12 h-12 mx-auto text-gray-300" />
                      <p className="text-xs font-bold">No active orders found in this account portfolio yet.</p>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      
                      {/* Active Order History list table */}
                      <div className="overflow-x-auto border border-gray-150 rounded-2xl bg-white shadow-inner">
                        <table className="w-full text-xs text-left">
                          <thead className="bg-gray-50/80 border-b border-gray-150 text-gray-500 font-bold uppercase tracking-wider text-[10px]">
                            <tr>
                              <th className="p-4">Order ID</th>
                              <th className="p-4">Recipient</th>
                              <th className="p-4">Delivery Coordinates</th>
                              <th className="p-4">Amount</th>
                              <th className="p-4">Status Status</th>
                              {currentUser.role !== 'buyer' && <th className="p-4">Actions Action</th>}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-100">
                            {orders.map((o) => (
                              <tr 
                                key={o.id} 
                                onClick={() => setSelectedOrder(o)}
                                className={`hover:bg-gray-50 cursor-pointer transition-colors ${selectedOrder && selectedOrder.id === o.id ? 'bg-emerald-50/40' : ''}`}
                              >
                                <td className="p-4 font-bold text-gray-900 font-mono">#{o.id}</td>
                                <td className="p-4 font-semibold text-gray-900">
                                  {o.fullName}
                                  <span className="block text-[9px] text-gray-400 mt-0.5 font-normal">{o.phone}</span>
                                </td>
                                <td className="p-4 text-gray-500 max-w-xs truncate">{o.address}, {o.city}</td>
                                <td className="p-4 font-extrabold text-emerald-600">
                                  {formatPrice(o.totalCost, Math.round(o.totalCost / 278))}
                                </td>
                                <td className="p-4">
                                  <span className={`inline-block text-[9px] font-extrabold px-2 py-0.5 rounded-full border uppercase ${
                                    o.status === 'Delivered'
                                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                      : o.status === 'Shipped'
                                        ? 'bg-sky-50 text-sky-700 border-sky-200'
                                        : o.status === 'Processing'
                                          ? 'bg-amber-50 text-amber-700 border-amber-200'
                                          : 'bg-gray-50 text-gray-700 border-gray-200'
                                  }`}>
                                    {o.status}
                                  </span>
                                </td>
                                {currentUser.role !== 'buyer' && (
                                  <td className="p-4" onClick={(e) => e.stopPropagation()}>
                                    <select 
                                      value={o.status}
                                      onChange={(e) => handleUpdateOrderStatus(o.id, e.target.value)}
                                      className="px-2.5 py-1 bg-gray-50 border border-gray-200 rounded-lg text-xs font-bold text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#002045]/10"
                                    >
                                      <option value="Placed">Placed</option>
                                      <option value="Processing">Processing</option>
                                      <option value="Shipped">Shipped</option>
                                      <option value="Delivered">Delivered</option>
                                    </select>
                                  </td>
                                )}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>

                      {/* Selected order visual tracking details page */}
                      {selectedOrder && (
                        <div className="bg-gray-50 border border-gray-100 rounded-3xl p-6 text-left space-y-5">
                          <h4 className="font-extrabold text-gray-900 text-xs flex items-center justify-between">
                            <span>Order Audit Logs for #{selectedOrder.id}</span>
                            <span className="text-[10px] text-gray-500 font-normal">Active Escrow Verification</span>
                          </h4>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            
                            {/* Items list */}
                            <div className="space-y-3">
                              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Ordered Inventory Items</p>
                              <div className="space-y-2.5">
                                {selectedOrder.cartItems.map((item: any, i: number) => (
                                  <div key={i} className="flex gap-3 items-center bg-white p-2.5 rounded-xl border border-gray-100">
                                    <img 
                                      src={item.product.image} 
                                      alt={item.product.title} 
                                      className="w-10 h-10 object-cover rounded-lg border border-gray-100 shrink-0"
                                      referrerPolicy="no-referrer"
                                    />
                                    <div className="min-w-0 flex-1">
                                      <p className="text-[11px] font-bold text-gray-900 truncate">{item.product.title}</p>
                                      <p className="text-[10px] text-gray-500 mt-0.5">
                                        Qty: <strong>{item.quantity}</strong> | Merchant: {item.selectedSeller?.sellerName || 'Zorify Merchant'}
                                      </p>
                                    </div>
                                    <span className="text-xs font-bold text-emerald-600 shrink-0">
                                      {formatPrice(
                                        (currency === 'USD' ? item.selectedSeller.pricePKR : item.selectedSeller.pricePKR) * item.quantity,
                                        (currency === 'USD' ? item.selectedSeller.priceUSD : item.selectedSeller.priceUSD) * item.quantity
                                      )}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {/* Logistics history logs trail */}
                            <div className="space-y-3">
                              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Tracking Audit Trail</p>
                              <div className="space-y-4 relative border-l-2 border-emerald-100 pl-4 py-2">
                                {selectedOrder.trackingHistory && selectedOrder.trackingHistory.map((step: any, idx: number) => (
                                  <div key={idx} className="relative text-left">
                                    {/* Small circle indicator */}
                                    <div className="absolute -left-[21px] top-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 border border-white" />
                                    <p className="text-[11px] font-bold text-gray-900 uppercase">{step.status}</p>
                                    <p className="text-[10px] text-gray-500 mt-0.5">Fulfillment sequence checked. Timestamp recorded.</p>
                                    <span className="text-[9px] text-gray-400 font-mono mt-0.5 block">{new Date(step.timestamp).toLocaleString()}</span>
                                  </div>
                                ))}
                              </div>
                            </div>

                          </div>
                        </div>
                      )}

                    </div>
                  )}

                </div>
              )}

              {/* TAB 3: INVENTORY MANAGEMENT */}
              {activeTab === 'inventory' && (
                <div className="space-y-6">
                  <div className="border-b border-gray-100 pb-5">
                    <h3 className="text-base font-extrabold text-gray-900">
                      {currentUser.role === 'admin' ? 'HHC Sourced & Platform Products Catalog' : 'My Store Inventory Listings'}
                    </h3>
                    <p className="text-xs text-gray-400 mt-0.5">
                      {currentUser.role === 'admin'
                        ? 'Perform bulk updates, synchronize Pakistani HHC Dropshipping feeds, and monitor global catalog inventories.'
                        : 'Upload new items, adjust pricing structures, and manage active shop catalog items.'}
                    </p>
                  </div>

                  {/* Add Product form section */}
                  <div className="bg-gray-50 border border-gray-150 rounded-2xl p-6 text-left">
                    <h4 className="text-xs font-black text-[#002045] uppercase tracking-wider mb-4 flex items-center gap-1.5">
                      <Plus className="w-4 h-4 text-emerald-500" />
                      List a New Product in Public Storefront
                    </h4>
                    
                    <form onSubmit={handleAddProduct} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-gray-500 uppercase">PRODUCT TITLE</label>
                        <input 
                          type="text" 
                          required
                          value={newTitle}
                          onChange={(e) => setNewTitle(e.target.value)}
                          placeholder="e.g. Mechanical RGB Gaming Keyboard"
                          className="w-full px-3 py-2 bg-white border border-gray-200 rounded-xl text-xs text-gray-900 focus:outline-none focus:border-[#002045]"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-gray-500 uppercase">CATEGORY DEPARTMENT</label>
                        <select 
                          value={newCategory}
                          onChange={(e: any) => setNewCategory(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-gray-200 rounded-xl text-xs text-gray-900 focus:outline-none focus:border-[#002045]"
                        >
                          <option value="Electronics">Electronics</option>
                          <option value="Fashion">Fashion</option>
                          <option value="Beauty">Beauty</option>
                          <option value="Home">Home</option>
                          <option value="Baby">Baby</option>
                          <option value="Books">Books</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-gray-500 uppercase">BASE WHOLESALE PRICE (PKR)</label>
                        <input 
                          type="number" 
                          required
                          value={newPricePKR}
                          onChange={(e) => setNewPricePKR(e.target.value)}
                          placeholder="e.g. 4500"
                          className="w-full px-3 py-2 bg-white border border-gray-200 rounded-xl text-xs text-gray-900 focus:outline-none focus:border-[#002045]"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-gray-500 uppercase">IMAGE URL (UNSPLASH OR CDN)</label>
                        <input 
                          type="url" 
                          required
                          value={newImage}
                          onChange={(e) => setNewImage(e.target.value)}
                          placeholder="e.g. https://images.unsplash.com/photo-..."
                          className="w-full px-3 py-2 bg-white border border-gray-200 rounded-xl text-xs text-gray-900 focus:outline-none focus:border-[#002045]"
                        />
                      </div>

                      <div className="sm:col-span-2 space-y-1">
                        <label className="block text-[10px] font-bold text-gray-500 uppercase">PRODUCT SPECIFICATIONS (COMMA SEPARATED)</label>
                        <input 
                          type="text" 
                          value={newSpecs}
                          onChange={(e) => setNewSpecs(e.target.value)}
                          placeholder="Key: Value, Key2: Value2"
                          className="w-full px-3 py-2 bg-white border border-gray-200 rounded-xl text-xs text-gray-900 focus:outline-none"
                        />
                      </div>

                      <div className="sm:col-span-2 space-y-1">
                        <label className="block text-[10px] font-bold text-gray-500 uppercase">PRODUCT DESCRIPTION</label>
                        <textarea 
                          rows={2}
                          value={newDescription}
                          onChange={(e) => setNewDescription(e.target.value)}
                          placeholder="Provide descriptive details, materials, aesthetics, box inclusions..."
                          className="w-full px-3 py-2 bg-white border border-gray-200 rounded-xl text-xs text-gray-900 focus:outline-none resize-none"
                        />
                      </div>

                      <div className="sm:col-span-2 pt-2 text-right">
                        <button 
                          type="submit"
                          className="bg-[#002045] hover:bg-[#003060] text-white px-6 py-2.5 rounded-xl font-bold text-xs cursor-pointer shadow-md"
                        >
                          Upload product to database catalog
                        </button>
                      </div>
                    </form>
                  </div>

                  {/* Active listings view */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest text-left">Active Sourced Catalog Items ({products.length})</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {products.slice(0, 8).map((p) => (
                        <div key={p.id} className="flex gap-4 p-3 bg-white border border-gray-100 rounded-xl items-center">
                          <img 
                            src={p.image} 
                            alt={p.title} 
                            className="w-12 h-12 rounded-lg object-cover bg-gray-50 border border-gray-100 shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div className="min-w-0 flex-1 text-left">
                            <h5 className="text-xs font-bold text-gray-900 truncate">{p.title}</h5>
                            <p className="text-[10px] text-gray-500 mt-0.5">{p.category} | Starts at {formatPrice(p.pricePKR, p.priceUSD)}</p>
                          </div>
                          {p.id.startsWith('hhc-') && (
                            <span className="text-[8px] bg-indigo-50 border border-indigo-200 text-indigo-700 font-extrabold px-2 py-0.5 rounded-full uppercase shrink-0">
                              HHC Sourced
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                </div>
              )}

              {/* TAB 4: ADMIN EMAIL LOGS */}
              {activeTab === 'emails' && (
                <div className="space-y-6">
                  <div className="border-b border-gray-100 pb-5">
                    <h3 className="text-base font-extrabold text-gray-900">Admin Email Notifications Log (Nodemailer / Resend Queue)</h3>
                    <p className="text-xs text-gray-400 mt-0.5">Audit log of system email dispatches issued on customer order bookings.</p>
                  </div>

                  {emails.length === 0 ? (
                    <div className="text-center py-20 text-gray-400 space-y-4">
                      <Mail className="w-12 h-12 mx-auto text-gray-300" />
                      <p className="text-xs font-bold">No dispatch logs found in Nodemailer transit yet.</p>
                    </div>
                  ) : (
                    <div className="space-y-4 text-left">
                      {emails.map((m) => (
                        <div key={m.id} className="bg-gray-50 border border-gray-150 rounded-2xl overflow-hidden shadow-inner font-mono text-[10px]">
                          <div className="bg-[#002045] text-white p-3 flex justify-between items-center text-[11px] font-sans">
                            <span className="font-extrabold flex items-center gap-1.5 text-xs text-emerald-400">
                              <Sparkles className="w-4 h-4" />
                              SMTP Dispatch: #{m.id}
                            </span>
                            <span className="text-slate-300 text-[10px]">{new Date(m.sentAt).toLocaleString()}</span>
                          </div>
                          
                          <div className="p-4 space-y-2.5 text-gray-600">
                            <div>
                              <span className="text-gray-400 font-bold font-sans">To Admin Address:</span> <strong className="text-gray-900">{m.to}</strong>
                            </div>
                            <div>
                              <span className="text-gray-400 font-bold font-sans">Subject Line:</span> <strong className="text-gray-900">{m.subject}</strong>
                            </div>
                            <hr className="border-gray-200/60 my-2" />
                            <div>
                              <p className="text-gray-400 font-bold font-sans mb-1 uppercase tracking-wider text-[9px]">HTML EMAIL BODY</p>
                              <div className="bg-white p-3.5 rounded-xl border border-gray-200 text-gray-800 leading-relaxed font-sans text-xs" dangerouslySetInnerHTML={{ __html: m.body }} />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                </div>
              )}

              {/* TAB 5: BUYER ADDRESSES */}
              {activeTab === 'addresses' && (
                <div className="space-y-6">
                  <div className="border-b border-gray-100 pb-5">
                    <h3 className="text-base font-extrabold text-gray-900">Delivery Address Book</h3>
                    <p className="text-xs text-gray-400 mt-0.5">Securely manage your destination coordinates for high-speed escrow dispatching.</p>
                  </div>

                  <form onSubmit={handleSaveAddress} className="max-w-md text-left space-y-4 bg-gray-50 border border-gray-150 p-6 rounded-2xl">
                    <div className="space-y-1">
                      <label className="block text-[10px] font-bold text-gray-500 uppercase">SECURE DELIVERY DESTINATION ADDRESS</label>
                      <textarea 
                        rows={3}
                        required
                        value={shippingAddress}
                        onChange={(e) => setShippingAddress(e.target.value)}
                        placeholder="Type full address..."
                        className="w-full px-3.5 py-2.5 bg-white border border-gray-200 focus:border-[#002045] focus:outline-none focus:ring-2 focus:ring-[#002045]/10 rounded-xl text-xs text-gray-900 resize-none shadow-sm"
                      />
                    </div>

                    <button 
                      type="submit"
                      className="bg-[#002045] hover:bg-[#003060] text-white px-5 py-2.5 rounded-xl font-bold text-xs cursor-pointer shadow-md"
                    >
                      Save Coordinates Securely
                    </button>
                  </form>
                </div>
              )}
            </>
          )}

        </div>

      </div>

    </div>
  );
}
