import React, { useState } from 'react';
import { X, ShieldCheck, HelpCircle, FileText, CheckCircle2, ChevronRight, Award, AlertCircle } from 'lucide-react';

interface SellerApplyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SellerApplyModal({ isOpen, onClose }: SellerApplyModalProps) {
  const [storeName, setStoreName] = useState('');
  const [category, setCategory] = useState('Fashion');
  const [website, setWebsite] = useState('');
  const [location, setLocation] = useState('Dubai, AE');
  const [email, setEmail] = useState('');
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState<any | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!storeName || !email) return;

    setIsSubmitting(true);
    setResult(null);

    try {
      const response = await fetch('/api/seller/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ storeName, category, website, location, email })
      });
      const data = await response.json();
      
      // Simulate real verification check lag
      setTimeout(() => {
        setResult(data);
        setIsSubmitting(false);
      }, 1500);
    } catch (err) {
      console.error(err);
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setStoreName('');
    setCategory('Fashion');
    setWebsite('');
    setLocation('Dubai, AE');
    setEmail('');
    setResult(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto" role="dialog" aria-modal="true">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-gray-900/60 backdrop-blur-xs transition-opacity" 
        onClick={onClose} 
      />

      {/* Container */}
      <div className="relative bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden z-10 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-50/70">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-indigo-600" />
            <h2 className="text-sm font-bold text-gray-900">
              Apply for ZV Merchant Verification
            </h2>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 hover:bg-gray-100 rounded-full text-gray-400 hover:text-gray-600 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {!result ? (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
            <div className="text-xs text-gray-500 leading-relaxed bg-indigo-50 border border-indigo-100/50 p-3.5 rounded-xl">
              <strong>MFP Verification (MFPV) Program:</strong> Join 5,000+ elite regional partners. Verified merchants average 4.2x greater sales velocities and instant safe buy buyer insurance. Fill in your details for real-time MFPV score rating simulation.
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold text-gray-500 mb-1">STORE/BRAND ENTITY NAME</label>
                <input 
                  type="text" 
                  required
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  placeholder="e.g. Aura Direct, Prime Boutique"
                  className="w-full px-3.5 py-2 bg-gray-50 border border-gray-200 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-100 rounded-xl text-xs text-gray-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 mb-1">MAIN DIVISION CATEGORY</label>
                  <select 
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 focus:border-indigo-500 focus:outline-none rounded-xl text-xs text-gray-900"
                  >
                    <option value="Fashion">Fashion & Apparel</option>
                    <option value="Beauty">Organic Beauty</option>
                    <option value="Electronics">Slick Electronics</option>
                    <option value="Home">Home Decor & Smart Tech</option>
                    <option value="Baby">Baby Care</option>
                    <option value="Books">Books & Media</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-gray-500 mb-1">REGIONAL HEADQUARTERS</label>
                  <select 
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 focus:border-indigo-500 focus:outline-none rounded-xl text-xs text-gray-900"
                  >
                    <option value="Dubai, AE">Dubai, UAE</option>
                    <option value="Lahore, PK">Lahore, Pakistan</option>
                    <option value="Karachi, PK">Karachi, Pakistan</option>
                    <option value="Islamabad, PK">Islamabad, Pakistan</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-500 mb-1">WEBSITE DOMAIN</label>
                <input 
                  type="url" 
                  required
                  value={website}
                  onChange={(e) => setWebsite(e.target.value)}
                  placeholder="e.g. https://mybrand.com"
                  className="w-full px-3.5 py-2 bg-gray-50 border border-gray-200 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-100 rounded-xl text-xs text-gray-900"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-500 mb-1">CONTACT EMAIL</label>
                <input 
                  type="email" 
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. partnership@mybrand.com"
                  className="w-full px-3.5 py-2 bg-gray-50 border border-gray-200 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-100 rounded-xl text-xs text-gray-900"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-gray-100 flex justify-end gap-2 text-xs">
              <button 
                type="button" 
                onClick={onClose}
                className="border border-gray-200 hover:border-gray-300 text-gray-600 px-4 py-2.5 rounded-xl font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button 
                type="submit"
                disabled={isSubmitting}
                className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white px-5 py-2.5 rounded-xl font-bold flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Auditing Ledger...
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4 text-emerald-300" />
                    Submit Verification
                  </>
                )}
              </button>
            </div>
          </form>
        ) : (
          <div className="p-6 space-y-5 text-center flex flex-col justify-between overflow-y-auto">
            <div className="space-y-4">
              <div className="inline-flex w-14 h-14 bg-indigo-50 rounded-full items-center justify-center text-indigo-600 border-4 border-indigo-100">
                <ShieldCheck className="w-7 h-7" />
              </div>

              <div className="space-y-1">
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-extrabold px-3 py-1 rounded-full uppercase tracking-wider">
                  {result.status}
                </span>
                <h3 className="text-base font-bold text-gray-900 pt-2">Audit Complete: {storeName}</h3>
                <p className="text-xs text-gray-500 max-w-sm mx-auto">
                  {result.message} Your store has evaluated successfully on secure platform endpoints.
                </p>
              </div>

              <div className="bg-gray-50 border border-gray-100 p-4 rounded-2xl max-w-sm mx-auto text-xs text-left space-y-2.5">
                <div className="flex justify-between font-bold">
                  <span>Preliminary Score</span>
                  <span className="text-indigo-600">{result.score}%</span>
                </div>
                <hr className="border-gray-200/50" />
                <div className="flex items-center justify-between text-gray-500 text-[11px]">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Web domain lock
                  </span>
                  <span className="text-emerald-600 font-semibold">AUTHENTIC</span>
                </div>
                <div className="flex items-center justify-between text-gray-500 text-[11px]">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Geolocation compliance
                  </span>
                  <span className="text-emerald-600 font-semibold">COMPLIANT</span>
                </div>
                <div className="flex items-center justify-between text-gray-500 text-[11px]">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Preliminary risk rate
                  </span>
                  <span className="text-emerald-600 font-semibold">LOW RISK</span>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-gray-100 flex justify-end gap-2 text-xs">
              <button 
                onClick={handleReset}
                className="text-indigo-600 hover:bg-indigo-50 border border-indigo-200 px-4 py-2 rounded-xl font-bold transition-all cursor-pointer"
              >
                Retry Another Brand
              </button>
              <button 
                onClick={onClose}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-xl font-bold shadow-sm transition-all cursor-pointer"
              >
                Acknowledge
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
