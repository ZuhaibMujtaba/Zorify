export interface Product {
  id: string;
  title: string;
  category: 'Fashion' | 'Beauty' | 'Electronics' | 'Home' | 'Baby' | 'Books';
  pricePKR: number;
  priceUSD: number;
  image: string;
  rating: number;
  reviewsCount: number;
  isFlashDeal?: boolean;
  discount?: number; // percentage e.g. 45
  originalPricePKR?: number;
  originalPriceUSD?: number;
  description: string;
  topChoice?: boolean;
  specifications?: Record<string, string>;
}

export interface Seller {
  id: string;
  name: string;
  rating: number;
  avatar: string;
  isVerified: boolean;
  itemsCount: string;
  itemImages: string[];
  location: string;
  deliverySpeed: string;
}

export interface SellerOffer {
  sellerId: string;
  sellerName: string;
  sellerRating: number;
  sellerAvatar: string;
  pricePKR: number;
  priceUSD: number;
  reliabilityScore: number; // 0-100
  deliveryDays: number;
  isVerified: boolean;
  stockStatus: 'In Stock' | 'Low Stock' | 'Out of Stock';
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedSeller: {
    sellerId: string;
    sellerName: string;
    pricePKR: number;
    priceUSD: number;
    isVerified: boolean;
  };
}

export interface AISearchResult {
  reply: string;
  matchedProductIds: string[];
  recommendationExplanation: string;
}
