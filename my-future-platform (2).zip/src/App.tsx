import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  ShoppingCart, 
  Star, 
  Globe, 
  ShieldCheck, 
  ChevronRight, 
  Lock, 
  Award, 
  Heart, 
  Share2, 
  Mail, 
  Users, 
  HelpCircle, 
  CheckCircle2, 
  Send, 
  ArrowRight, 
  Clock, 
  Zap,
  Info,
  ExternalLink,
  MessageSquare,
  Gift,
  X,
  Bell
} from 'lucide-react';

import Header from './components/Header';
import CartDrawer from './components/CartDrawer';
import ComparisonModal from './components/ComparisonModal';
import SellerApplyModal from './components/SellerApplyModal';
import AIConsultant from './components/AIConsultant';
import LaunchControl from './components/LaunchControl';
import DashboardPortal from './components/DashboardPortal';

import { PRODUCTS, SELLERS, getOffersForProduct } from './data';
import { Product, SellerOffer, CartItem } from './types';

export default function App() {
  // Global States
  const [cart, setCart] = useState<CartItem[]>([]);
  const [currency, setCurrency] = useState<'USD' | 'PKR'>('USD');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [highlightedProductIds, setHighlightedProductIds] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'all' | 'popular' | 'recent'>('all');
  const [isLaunchControlOpen, setIsLaunchControlOpen] = useState(false);

  // Operations Session & Dynamic Products States
  const [currentUser, setCurrentUser] = useState<{ id: string; username: string; role: 'buyer' | 'seller' | 'admin'; sessionToken: string } | null>(() => {
    try {
      const saved = localStorage.getItem('zorify-current-user');
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      return null;
    }
  });
  const [dynamicProducts, setDynamicProducts] = useState<Product[]>([]);
  const [cartDrawerForceStep, setCartDrawerForceStep] = useState<'cart' | 'shipping'>('cart');
  
  // Modals / Overlays triggers
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [comparisonProduct, setComparisonProduct] = useState<Product | null>(null);
  const [isSellerApplyOpen, setIsSellerApplyOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  
  // Custom dialog flags
  const [showHowItWorks, setShowHowItWorks] = useState(false);
  const [showSOS, setShowSOS] = useState(false);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [showNotificationModal, setShowNotificationModal] = useState(false);
  const [notificationEmail, setNotificationEmail] = useState('');
  
  // Interactive mini settings
  const [likedProducts, setLikedProducts] = useState<string[]>([]);
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [successToast, setSuccessToast] = useState<string | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  
  // Invite inputs
  const [inviteName, setInviteName] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');

  // Daily countdown simulation
  const [countdown, setCountdown] = useState({ hours: 16, minutes: 11, seconds: 14 });

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else {
          return { hours: 23, minutes: 59, seconds: 59 }; // reset daily deal loop
        }
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const fetchProducts = async () => {
    try {
      const res = await fetch('/api/products');
      if (res.ok) {
        const data = await res.json();
        setDynamicProducts(data);
      } else {
        setDynamicProducts(PRODUCTS);
      }
    } catch (err) {
      setDynamicProducts(PRODUCTS);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  // Toast auto-dismiss helper
  useEffect(() => {
    if (successToast) {
      const dismiss = setTimeout(() => setSuccessToast(null), 4000);
      return () => clearTimeout(dismiss);
    }
  }, [successToast]);

  // Toast trigger helper
  const triggerToast = (msg: string) => {
    setSuccessToast(msg);
  };

  const handleGlobalSearch = async (queryStr: string) => {
    if (!queryStr.trim()) {
      setHighlightedProductIds([]);
      return;
    }
    setIsSearching(true);
    try {
      const response = await fetch('/api/gemini/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: queryStr })
      });
      const data = await response.json();
      if (data.matchedProductIds && data.matchedProductIds.length > 0) {
        setHighlightedProductIds(data.matchedProductIds);
        triggerToast(`Zorify AI found ${data.matchedProductIds.length} recommendations matching your query.`);
        
        // Smoothly scroll down to the product feed
        const element = document.getElementById('trending-section');
        if (element) {
          element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      } else {
        setHighlightedProductIds([]);
        triggerToast('No products matched perfectly. Try asking for specific items!');
      }
    } catch (e) {
      console.error(e);
      // Basic keyword fallback
      const normalized = queryStr.toLowerCase();
      const matches = PRODUCTS.filter(p => p.title.toLowerCase().includes(normalized)).map(p => p.id);
      setHighlightedProductIds(matches);
    } finally {
      setIsSearching(false);
    }
  };

  // Cart operations
  const handleAddToCartFromOffer = (product: Product, offer: any) => {
    setCart((prev) => {
      const exists = prev.find(
        (item) => item.product.id === product.id && item.selectedSeller.sellerId === offer.sellerId
      );
      if (exists) {
        return prev.map((item) =>
          item.product.id === product.id && item.selectedSeller.sellerId === offer.sellerId
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [
        ...prev,
        {
          product,
          quantity: 1,
          selectedSeller: {
            sellerId: offer.sellerId,
            sellerName: offer.sellerName,
            pricePKR: offer.pricePKR,
            priceUSD: offer.priceUSD,
            isVerified: offer.isVerified
          }
        }
      ];
    });

    setComparisonProduct(null);
    setQuickViewProduct(null);
    setIsCartOpen(true);
    triggerToast(`Added ${product.title} from ${offer.sellerName} to your cart.`);
  };

  const handleUpdateQuantity = (productId: string, quantity: number, sellerId: string) => {
    if (quantity <= 0) {
      handleRemoveItem(productId, sellerId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId && item.selectedSeller.sellerId === sellerId
          ? { ...item, quantity }
          : item
      )
    );
  };

  const handleRemoveItem = (productId: string, sellerId: string) => {
    setCart((prev) =>
      prev.filter((item) => !(item.product.id === productId && item.selectedSeller.sellerId === sellerId))
    );
    triggerToast('Item removed from shopping cart.');
  };

  const handleToggleLike = (productId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLikedProducts((prev) =>
      prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]
    );
    
    const isLikedNow = !likedProducts.includes(productId);
    triggerToast(isLikedNow ? 'Item added to your watch list.' : 'Item removed from watch list.');
  };

  const handleSubscribeNewsletter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    triggerToast('Zorify Subscription Secured! Check inbox for authentic luxury coupons.');
    setNewsletterEmail('');
  };

  const handleSubscribeNotifications = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notificationEmail || !notificationEmail.trim()) return;
    try {
      const res = await fetch('/api/notifications/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: notificationEmail })
      });
      const data = await res.json();
      if (res.ok) {
        triggerToast(data.message || 'Subscribed successfully to real-time alerts!');
        setNotificationEmail('');
        setShowNotificationModal(false);
      } else {
        triggerToast(data.error || 'Subscription failed. Please check your email.');
      }
    } catch (err) {
      triggerToast('Network error while subscribing. Please try again.');
    }
  };

  const handleSendInvite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteName || !inviteEmail) return;
    triggerToast(`Invite dispatched successfully to ${inviteEmail}! 50 Zorify Coins queued.`);
    setInviteName('');
    setInviteEmail('');
    setShowInviteModal(false);
  };

  // Filter products matching current category and main tab selection
  const getDisplayProducts = () => {
    let list = dynamicProducts.length > 0 ? dynamicProducts : PRODUCTS;
    
    // Category filter
    if (selectedCategory && selectedCategory !== 'All') {
      list = list.filter((p) => p.category === selectedCategory);
    }

    // Interactive main tab tags filter
    if (activeTab === 'popular') {
      list = [...list].sort((a, b) => b.reviewsCount - a.reviewsCount);
    } else if (activeTab === 'recent') {
      list = [...list].reverse();
    }

    return list;
  };

  // Direct Add to Cart / Order Now using Prime/First Seller
  const handleDirectAddToCart = (product: Product, orderNow = false) => {
    const offers = getOffersForProduct(product.id);
    const defaultOffer = offers.length > 0 ? offers[0] : {
      sellerId: 'prime-global',
      sellerName: 'Prime Global Direct',
      pricePKR: product.pricePKR,
      priceUSD: product.priceUSD,
      isVerified: true
    };
    
    setCart((prev) => {
      const exists = prev.find(
        (item) => item.product.id === product.id && item.selectedSeller.sellerId === defaultOffer.sellerId
      );
      if (exists) {
        return prev.map((item) =>
          item.product.id === product.id && item.selectedSeller.sellerId === defaultOffer.sellerId
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [
        ...prev,
        {
          product,
          quantity: 1,
          selectedSeller: {
            sellerId: defaultOffer.sellerId,
            sellerName: defaultOffer.sellerName,
            pricePKR: defaultOffer.pricePKR,
            priceUSD: defaultOffer.priceUSD,
            isVerified: defaultOffer.isVerified
          }
        }
      ];
    });

    if (orderNow) {
      setCartDrawerForceStep('shipping');
      setIsCartOpen(true);
      triggerToast(`Redirecting you directly to safe checkout for ${product.title}!`);
    } else {
      setCartDrawerForceStep('cart');
      setIsCartOpen(true);
      triggerToast(`Added ${product.title} to your cart.`);
    }
  };

  const formatPriceGlobal = (pkr: number, usd: number) => {
    if (currency === 'USD') {
      return `USD $${usd.toLocaleString()}`;
    }
    return `PKR ${pkr.toLocaleString()}`;
  };

  return (
    <div className="bg-[#f7fafc] text-slate-800 min-h-screen flex flex-col font-sans">
      
      {/* Success alert toast floats at top right */}
      {successToast && (
        <div className="fixed top-24 right-6 z-50 bg-[#002045] text-white px-5 py-4 rounded-2xl shadow-2xl border border-white/10 flex items-center gap-3 animate-fade-in max-w-sm">
          <div className="p-1 rounded-lg bg-emerald-500 text-white shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold leading-relaxed">{successToast}</p>
          </div>
        </div>
      )}

      {/* Main app navigation header */}
      <Header 
        cartCount={cart.reduce((s, i) => s + i.quantity, 0)}
        onCartOpen={() => setIsCartOpen(true)}
        currency={currency}
        setCurrency={setCurrency}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onSearch={handleGlobalSearch}
        isSearching={isSearching}
        onShowHowItWorks={() => setShowHowItWorks(true)}
        onShowSOS={() => setShowSOS(true)}
        onShowLaunchControl={() => setIsLaunchControlOpen(true)}
        onShowNotifications={() => setShowNotificationModal(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-6 sm:py-10 space-y-16">
        
        {/* Landing Hero Screen with protection check details */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center justify-between min-h-[500px]">
          {/* Infographics and Title block */}
          <div className="lg:col-span-6 space-y-6 text-left">
            <div className="inline-flex items-center gap-2 bg-[#002045]/5 hover:bg-[#002045]/10 text-[#002045] px-4 py-1.5 rounded-full border border-[#002045]/10 font-bold text-xs uppercase tracking-wider transition-all">
              <ShieldCheck className="w-4 h-4 text-emerald-500 flex-shrink-0 animate-pulse" />
              <span>Zorify Safe Buy Guarantee</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-extrabold text-[#002045] tracking-tight leading-tight">
              The Smartest Marketplace <br />
              for <span className="text-emerald-700 bg-emerald-50/80 px-3 py-0.5 rounded-xl border border-emerald-100">Verified AI-Commerce</span>
            </h1>

            <p className="text-gray-500 text-sm leading-relaxed max-w-xl">
              Experience zero-risk shopping with Zorify's advanced verification engine. We filter the noise to bring you authentic products from audited, top-rated global sellers with real-time price monitoring.
            </p>

            <div className="flex flex-wrap gap-4 pt-2">
              <button 
                onClick={() => {
                  const element = document.getElementById('trending-section');
                  if (element) {
                    element.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }
                }}
                className="bg-[#002045] hover:bg-[#003060] text-white px-8 py-4 rounded-xl font-bold text-xs flex items-center gap-2 transition-all shadow-md hover:shadow-lg cursor-pointer transform hover:translate-y-[-1px]"
              >
                Start Exploring
                <ArrowRight className="w-4 h-4 text-emerald-400" />
              </button>
              <button 
                onClick={() => setShowHowItWorks(true)}
                className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-8 py-4 rounded-xl font-bold text-xs transition-all cursor-pointer"
              >
                How it Works
              </button>
            </div>

            {/* Satisfaction and Verified numbers summary */}
            <div className="flex items-center gap-8 pt-4 border-t border-gray-200/60 max-w-md">
              <div className="flex flex-col">
                <span className="text-2xl font-extrabold text-[#002045] tracking-tight">4.9/5</span>
                <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">User Satisfaction</span>
              </div>
              <div className="h-8 w-px bg-gray-200" />
              <div className="flex flex-col">
                <span className="text-2xl font-extrabold text-[#002045] tracking-tight">500k+</span>
                <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Verified Sales</span>
              </div>
            </div>
          </div>

          {/* Luxury Graphic Interior image Showcase */}
          <div className="lg:col-span-6 relative w-full aspect-video lg:aspect-square">
            <div className="absolute inset-0 bg-indigo-500/10 rounded-[2rem] transform rotate-3 scale-95 blur-2xl opacity-70" />
            
            <div className="relative h-full w-full rounded-[2.5rem] overflow-hidden border-4 border-white shadow-2xl max-h-[460px]">
              <img 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBOKN3spfK1B8YjmCUI_QcVWkeToOGxytiELjZ-2LGsrh-6FWbiQVN82rxANfaLxh7I5jy0Fn9Ul3DIewDuJ6bf8z4FKpXG-PaZ_I5yHkdma5o4DoKYYzCjgmSolTm2bc-E1KTKzHHbyJICXi08ty4C6mLMlXtZ9Q9byT-fK7kMLTIJbTkvYQ-k1GTaLf9SF3tc_mIp_B25EZhc8qtKBHTYRQ92fdhYzyXMUQ-z8pabMOfZeOPTMKBPhB3Gu-yVqx9OXyMH7odzEQ" 
                alt="Zorify Luxury Smart Marketplace" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              {/* Glass overlay update tag */}
              <div className="absolute bottom-5 left-5 right-5 glass-effect px-5 py-4 rounded-2xl border border-white/40 flex items-center gap-4 shadow-xl">
                <div className="bg-emerald-500 text-white p-2.5 rounded-xl shrink-0">
                  <ShieldCheck className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-[10px] font-extrabold text-indigo-950 uppercase tracking-wider">LATEST PROTECTION UPDATE</p>
                  <p className="text-xs font-bold text-[#002045]">100% Refund Policy Active</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Immersive Secure Operations Desk Portal */}
        {currentUser && (
          <section id="operations-desk-portal" className="scroll-mt-24 animate-fade-in">
            <DashboardPortal 
              currentUser={currentUser}
              onLogout={() => {
                localStorage.removeItem('zorify-current-user');
                setCurrentUser(null);
                triggerToast('Logged out of operations desk successfully.');
              }}
              currency={currency}
              products={dynamicProducts.length > 0 ? dynamicProducts : PRODUCTS}
              onRefreshProducts={fetchProducts}
              triggerToast={triggerToast}
            />
          </section>
        )}

        {/* Flash Deals section */}
        <section className="bg-[#002045] text-white rounded-[2.5rem] p-6 lg:p-10 relative overflow-hidden shadow-2xl">
          <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500 opacity-5 rounded-full blur-3xl -mr-32 -mt-32" />
          
          <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-8 border-b border-white/10 pb-6">
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-emerald-400">
                <Zap className="w-4 h-4 text-emerald-400 animate-bounce" />
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#85f6ad]">Flash Deals</span>
              </div>
              <h2 className="text-2xl font-extrabold text-white">Deal of the Day</h2>
            </div>

            {/* Simulated Live Countdown Tracker */}
            <div className="flex items-center gap-4 bg-white/10 px-5 py-3 rounded-2xl border border-white/10 select-none">
              <span className="text-[10px] font-extrabold text-emerald-400 tracking-wider">ENDS IN</span>
              <div className="flex items-center gap-2 text-white font-mono font-bold text-sm">
                <div className="flex flex-col items-center">
                  <span className="text-lg bg-[#002045] px-1.5 py-0.5 rounded border border-white/10 shrink-0">
                    {String(countdown.hours).padStart(2, '0')}
                  </span>
                  <span className="text-[9px] text-gray-400 mt-1 uppercase">HRS</span>
                </div>
                <span className="text-emerald-400 pb-4">:</span>
                
                <div className="flex flex-col items-center">
                  <span className="text-lg bg-[#002045] px-1.5 py-0.5 rounded border border-white/10 shrink-0">
                    {String(countdown.minutes).padStart(2, '0')}
                  </span>
                  <span className="text-[9px] text-gray-400 mt-1 uppercase">MIN</span>
                </div>
                <span className="text-emerald-400 pb-4">:</span>

                <div className="flex flex-col items-center">
                  <span className="text-lg bg-emerald-950 px-1.5 py-0.5 rounded border border-emerald-500/30 text-emerald-400 shrink-0">
                    {String(countdown.seconds).padStart(2, '0')}
                  </span>
                  <span className="text-[9px] text-gray-400 mt-1 uppercase">SEC</span>
                </div>
              </div>
            </div>
          </div>

          {/* Flash Deals Horizontal Carousel Layout */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {PRODUCTS.filter(p => p.isFlashDeal).map((product) => {
              const currentPrice = currency === 'USD' ? product.priceUSD : product.pricePKR;
              const originalPrice = currency === 'USD' ? product.originalPriceUSD : product.originalPricePKR;
              return (
                <div 
                  key={product.id}
                  onClick={() => setQuickViewProduct(product)}
                  className="bg-white rounded-2xl p-4 flex flex-col gap-3 group cursor-pointer hover:translate-y-[-4px] transition-all duration-300 relative text-slate-800 shadow-lg border border-gray-100"
                >
                  <div className="relative aspect-video rounded-xl overflow-hidden bg-gray-50">
                    <img 
                      src={product.image} 
                      alt={product.title} 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-2 left-2 bg-rose-500 text-white font-extrabold px-2 py-0.5 rounded-lg text-xs">
                      -{product.discount}%
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="text-indigo-600 font-extrabold text-[9px] uppercase tracking-wider">
                      {product.category}
                    </span>
                    <h3 className="text-xs font-bold text-[#002045] truncate group-hover:text-indigo-600 transition-colors">
                      {product.title}
                    </h3>
                    
                    <div className="flex items-baseline gap-2 pt-1.5">
                      <span className="text-sm font-extrabold text-emerald-600">
                        {currency === 'USD' ? `USD $${currentPrice}` : `PKR ${currentPrice.toLocaleString()}`}
                      </span>
                      {originalPrice && (
                        <span className="text-[10px] text-gray-400 line-through">
                          {currency === 'USD' ? `USD $${originalPrice}` : `PKR ${originalPrice.toLocaleString()}`}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Explore Department selector section */}
        <section id="categories-explore-section" className="space-y-6 text-center scroll-mt-24">
          <div className="space-y-1">
            <h2 className="text-lg font-bold text-[#002045]">Explore by Department</h2>
            <div className="w-10 h-1 bg-emerald-500 mx-auto rounded-full" />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {[
              { id: 'Fashion', icon: 'apparel', label: 'Fashion' },
              { id: 'Beauty', icon: 'face_6', label: 'Beauty' },
              { id: 'Electronics', icon: 'devices', label: 'Electronics' },
              { id: 'Home', icon: 'home', label: 'Home' },
              { id: 'Baby', icon: 'child_care', label: 'Baby' },
              { id: 'Books', icon: 'menu_book', label: 'Books' }
            ].map((cat) => {
              const isActive = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id === selectedCategory ? 'All' : cat.id);
                    const element = document.getElementById('trending-section');
                    if (element) {
                      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    }
                  }}
                  className={`group flex flex-col items-center gap-3 p-5 rounded-2xl transition-all duration-300 cursor-pointer ${isActive ? 'bg-white border-2 border-emerald-500 shadow-md transform translate-y-[-2px]' : 'bg-gray-50 hover:bg-white border-2 border-transparent hover:shadow-md'}`}
                >
                  <div className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${isActive ? 'bg-emerald-500 text-white' : 'bg-white text-[#002045] shadow-sm group-hover:bg-[#002045] group-hover:text-white'}`}>
                    <span className="material-symbols-outlined text-[28px]">{cat.icon}</span>
                  </div>
                  <span className={`text-xs font-bold ${isActive ? 'text-emerald-700' : 'text-gray-500 group-hover:text-[#002045]'}`}>
                    {cat.label}
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        {/* AI advisor chat consulting engine block */}
        <section>
          <AIConsultant 
            onHighlightProducts={(ids) => setHighlightedProductIds(ids)}
            currency={currency}
            onQuickView={(p) => setQuickViewProduct(p)}
            products={dynamicProducts.length > 0 ? dynamicProducts : PRODUCTS}
          />
        </section>

        {/* Authentic verified store sellers and merchants with expanded details */}
        <section className="space-y-8">
          <div className="flex justify-between items-center bg-gray-50/50 p-2.5 rounded-2xl">
            <h2 className="text-base font-bold text-[#002045] pl-1">Trustworthy Partners</h2>
            <button 
              onClick={() => triggerToast('Zorify Directory lists all 40+ accredited regional outlets.')}
              className="text-xs font-bold text-[#002045] hover:underline flex items-center gap-1 cursor-pointer"
            >
              See All Sellers
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {SELLERS.map((seller) => (
              <div 
                key={seller.id}
                className="bg-white p-4.5 rounded-2xl border border-gray-100 shadow-md hover:border-emerald-500/50 transition-all text-xs space-y-4"
              >
                <div className="flex items-center gap-3">
                  <img 
                    src={seller.avatar} 
                    alt={seller.name} 
                    className="w-12 h-12 rounded-full border border-gray-100 object-cover bg-white"
                    referrerPolicy="no-referrer"
                  />
                  <div className="min-w-0">
                    <h3 className="font-bold text-[#002045] truncate">{seller.name}</h3>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="bg-emerald-50 text-emerald-700 text-[9px] font-black px-1.5 py-0.5 rounded flex items-center gap-0.5">
                        <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600 shrink-0" />
                        VERIFIED
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex justify-between text-gray-500 font-medium">
                  <span>Items: <strong className="text-gray-900 font-bold">{seller.itemsCount}</strong></span>
                  <span>Rating: <strong className="text-gray-900 font-bold">{seller.rating}</strong></span>
                </div>

                {/* Seller expanded highlights thumbnails */}
                <div className="grid grid-cols-3 gap-1.5 pt-1">
                  {seller.itemImages.length > 0 ? (
                    seller.itemImages.slice(0, 3).map((img, i) => (
                      <div key={i} className="aspect-square rounded-lg bg-gray-50 border border-gray-100 overflow-hidden">
                        <img 
                          src={img} 
                          alt="seller showcase list" 
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    ))
                  ) : (
                    <div className="col-span-3 text-center py-2.5 bg-gray-50 rounded-lg text-[10px] text-gray-400">
                      Showcase items loading...
                    </div>
                  )}
                </div>
              </div>
            ))}

            {/* Simulated seller onboarding entry buttons */}
            <div 
              onClick={() => setIsSellerApplyOpen(true)}
              className="bg-gray-50 hover:bg-white border-2 border-dashed border-gray-200 hover:border-indigo-400 p-5 rounded-2xl flex flex-col items-center justify-center text-center cursor-pointer transition-all hover:shadow-md h-full group"
            >
              <div className="w-12 h-12 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center mb-2.5 group-hover:scale-105 transition-transform">
                <Users className="w-6 h-6" />
              </div>
              <p className="font-bold text-[#002045] text-xs">Join as a Verified Seller</p>
              <p className="text-[10px] text-gray-400 mt-1 max-w-xs">Access 5M+ active regional buyers globally.</p>
            </div>

            <div 
              onClick={() => setShowHowItWorks(true)}
              className="bg-gray-50 hover:bg-white border-2 border-dashed border-gray-200 hover:border-emerald-400 p-5 rounded-2xl flex flex-col items-center justify-center text-center cursor-pointer transition-all hover:shadow-md h-full group"
            >
              <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mb-2.5 group-hover:scale-105 transition-transform">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <p className="font-bold text-[#002045] text-xs">Verification Program</p>
              <p className="text-[10px] text-gray-400 mt-1 max-w-xs">Learn how we certify trusted merchants.</p>
            </div>
          </div>
        </section>

        {/* Trending Picks Section with Search query highlights focus */}
        <section className="space-y-8" id="trending-section">
          
          {/* Section summary header and Tab filter */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-100 pb-5">
            <div>
              <h2 className="text-lg font-bold text-[#002045]">Trending Picks</h2>
              <p className="text-xs text-gray-400 mt-0.5">Curated by our AI based on ZV reliability scores.</p>
            </div>

            <div className="flex bg-gray-100/80 p-1 rounded-xl">
              <button 
                onClick={() => setActiveTab('all')}
                className={`px-4 py-2 rounded-lg font-bold text-xs cursor-pointer transition-all ${activeTab === 'all' ? 'bg-white text-[#002045] shadow-sm' : 'text-gray-500 hover:text-gray-900'}`}
              >
                All Items
              </button>
              <button 
                onClick={() => setActiveTab('popular')}
                className={`px-4 py-2 rounded-lg font-bold text-xs cursor-pointer transition-all ${activeTab === 'popular' ? 'bg-white text-[#002045] shadow-sm' : 'text-gray-500 hover:text-gray-900'}`}
              >
                Popular
              </button>
              <button 
                onClick={() => setActiveTab('recent')}
                className={`px-4 py-2 rounded-lg font-bold text-xs cursor-pointer transition-all ${activeTab === 'recent' ? 'bg-white text-[#002045] shadow-sm' : 'text-gray-500 hover:text-gray-900'}`}
              >
                Recent
              </button>
            </div>
          </div>

          {/* Core products results grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {getDisplayProducts().map((product) => {
              const isLiked = likedProducts.includes(product.id);
              const isAIRecommended = highlightedProductIds.includes(product.id);
              
              return (
                <div 
                  key={product.id}
                  className={`bg-white rounded-2xl overflow-hidden shadow-md flex flex-col h-full hover:translate-y-[-4px] transition-all duration-300 relative ${isAIRecommended ? 'border-2 border-emerald-500 ring-4 ring-emerald-50 verified-pulse' : 'border border-gray-100'}`}
                >
                  
                  {/* Image container & tags */}
                  <div className="relative aspect-square bg-gray-50 cursor-pointer" onClick={() => setQuickViewProduct(product)}>
                    <img 
                      src={product.image} 
                      alt={product.title} 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />

                    {/* Top choice badge */}
                    {product.topChoice && (
                      <div className="absolute top-3 left-3 bg-[#805AD5] text-white text-[9px] font-black px-2.5 py-1 rounded-md uppercase tracking-wider">
                        TOP CHOICE
                      </div>
                    )}

                    {/* Highly interactive AI highlight tag */}
                    {isAIRecommended && (
                      <div className="absolute top-3 left-3 bg-emerald-600 text-white text-[9px] font-black px-2.5 py-1 rounded-md uppercase tracking-wider flex items-center gap-1 border border-emerald-400">
                        <Sparkles className="w-3 h-3 text-emerald-300 animate-spin" />
                        AI RECOMMENDED
                      </div>
                    )}

                    {/* Like watch button */}
                    <button 
                      onClick={(e) => handleToggleLike(product.id, e)}
                      className={`absolute top-3 right-3 w-8 h-8 rounded-full shadow-md flex items-center justify-center transition-all cursor-pointer ${isLiked ? 'bg-rose-50 text-rose-500' : 'bg-white/80 hover:bg-white text-gray-400'}`}
                    >
                      <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-500' : ''}`} />
                    </button>
                  </div>

                  {/* Body information content */}
                  <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-1.5" onClick={() => setQuickViewProduct(product)}>
                      <div className="flex items-center gap-1.5">
                        <span className="material-symbols-outlined text-amber-400 text-sm">star</span>
                        <span className="text-xs font-extrabold text-gray-800">{product.rating}</span>
                        <span className="text-[10px] text-gray-400">({product.reviewsCount})</span>
                      </div>
                      
                      <h3 className="text-xs font-bold text-[#002045] line-clamp-2 hover:text-[#003060] cursor-pointer transition-colors pt-0.5">
                        {product.title}
                      </h3>
                    </div>

                    <div className="space-y-3 pt-2">
                      <div className="border-t border-gray-100/60 pt-2 text-left">
                        <p className="text-[9px] font-extrabold text-[#002045]/60 uppercase tracking-widest">{currency} PRICE</p>
                        <p className="text-base font-extrabold text-emerald-600">
                          {formatPriceGlobal(product.pricePKR, product.priceUSD)}
                        </p>
                        <p className="text-[10px] text-gray-400 mt-0.5">
                          Approx.{' '}
                          <span className="font-bold text-gray-500">
                            {currency === 'USD'
                              ? `PKR ${product.pricePKR.toLocaleString()}`
                              : `USD $${product.priceUSD}`}
                          </span>
                        </p>
                      </div>

                      {/* Direct Cart and Direct Checkout Actions */}
                      <div className="space-y-2 pt-1">
                        <div className="grid grid-cols-2 gap-2">
                          <button 
                            onClick={() => handleDirectAddToCart(product, false)}
                            className="py-2 px-1 rounded-xl bg-gray-50 hover:bg-gray-150 text-[#002045] font-extrabold text-[11px] transition-all flex items-center justify-center gap-1 cursor-pointer shadow-xs border border-gray-200"
                            title="Add item to your cart"
                          >
                            <ShoppingCart className="w-3.5 h-3.5 text-emerald-600" />
                            Add to Cart
                          </button>
                          <button 
                            onClick={() => handleDirectAddToCart(product, true)}
                            className="py-2 px-1 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[11px] transition-all flex items-center justify-center gap-1 cursor-pointer shadow-md"
                            title="Direct checkout now"
                          >
                            <Zap className="w-3.5 h-3.5 text-emerald-300 fill-emerald-300 animate-pulse" />
                            Order Now
                          </button>
                        </div>
                        <button 
                          onClick={() => setComparisonProduct(product)}
                          className="w-full py-1.5 rounded-xl border-2 border-dashed border-[#002045]/20 hover:border-[#002045]/60 text-[#002045] font-bold text-[11px] hover:bg-[#002045]/5 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <Lock className="w-3 h-3 text-[#002045]/60" />
                          Compare 4 Sellers
                        </button>
                      </div>
                    </div>

                  </div>

                </div>
              );
            })}
          </div>
        </section>

        {/* Dynamic community referral reward programs */}
        <section className="bg-emerald-300 rounded-[2.5rem] p-6 lg:p-10 flex flex-col lg:flex-row items-center justify-between gap-8 relative overflow-hidden shadow-2xl text-slate-800 select-none">
          <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-emerald-400/30 rounded-full" />
          
          <div className="space-y-3.5 flex-1 text-center lg:text-left">
            <span className="inline-block bg-white text-emerald-800 font-extrabold px-3 py-1 rounded-full text-[10px] uppercase tracking-wider">
              GROW THE COMMUNITY
            </span>
            <h2 className="text-xl sm:text-2xl font-extrabold text-[#002045] tracking-tight leading-tight">
              Invite a Friend & Earn 50 Zorify Coins
            </h2>
            <p className="text-emerald-900 text-xs leading-relaxed max-w-md mx-auto lg:mx-0">
              Help your friends discover the safest way to shop online. When they make their first purchase, you both get coins to spend on any product listed across our depots.
            </p>
            <button 
              onClick={() => setShowInviteModal(true)}
              className="bg-[#002045] hover:bg-[#003060] text-white px-6 py-3 rounded-xl font-bold text-xs shadow-md transition-all cursor-pointer inline-flex items-center gap-1.5"
            >
              <Gift className="w-4 h-4 text-emerald-300" />
              Invite Now
            </button>
          </div>

          {/* Social Proof Group representation inside the panel */}
          <div className="flex-shrink-0 bg-white/40 backdrop-blur-md p-4 rounded-2xl border border-white/60 flex items-center gap-4 shadow-xl select-none">
            <div className="flex -space-x-3">
              {[
                'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80',
                'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=100&q=80',
                'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=100&q=80'
              ].map((av, index) => (
                <img 
                  key={index} 
                  src={av} 
                  alt="user avatar item" 
                  className="w-9 h-9 rounded-full border-2 border-white object-cover bg-white"
                  referrerPolicy="no-referrer"
                />
              ))}
            </div>
            <span className="text-[11px] font-bold text-[#002045]">Join 10,000+ top referrers</span>
          </div>
        </section>

      </main>

      {/* Complete descriptive Footer representation */}
      <footer className="bg-gray-100 border-t border-gray-200 text-xs mt-16 text-slate-600 select-none">
        
        {/* Core grid elements */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <span className="text-2xl font-black text-[#002045]">Zorify</span>
            <p className="text-gray-500 leading-relaxed text-xs max-w-xs">
              The world's most trusted AI-enhanced marketplace. Bridging high-tech efficiency with human-centric trust escrow guarantees.
            </p>
            <div className="flex gap-3">
              <button 
                onClick={() => triggerToast('Copied share link to copyboards.')}
                className="p-1.5 bg-white hover:bg-gray-50 border border-gray-200 text-[#002045] rounded-lg transition-colors cursor-pointer text-xs flex items-center gap-1.5 font-bold"
              >
                <Share2 className="w-4 h-4 text-indigo-500" />
                Share
              </button>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <h4 className="font-extrabold text-[#002045] uppercase tracking-wider text-[10px]">Platform</h4>
            <span onClick={() => setShowHowItWorks(true)} className="hover:underline hover:text-[#002045] transition-all cursor-pointer">Safe Buy Guarantee</span>
            <span onClick={() => setShowSOS(true)} className="hover:underline hover:text-[#002045] transition-all cursor-pointer">Help Center (SOS)</span>
            <span onClick={() => setIsSellerApplyOpen(true)} className="hover:underline hover:text-[#002045] transition-all cursor-pointer">ZV Verification</span>
          </div>

          <div className="flex flex-col gap-3">
            <h4 className="font-extrabold text-[#002045] uppercase tracking-wider text-[10px]">Company</h4>
            <span onClick={() => triggerToast('Zorify blog is online soon!')} className="hover:underline hover:text-[#002045] transition-all cursor-pointer">Blog</span>
            <span onClick={() => triggerToast('Review terms document inside standard applet rules.')} className="hover:underline hover:text-[#002045] transition-all cursor-pointer">Terms of Service</span>
            <span onClick={() => triggerToast('Review privacy policy data protections.')} className="hover:underline hover:text-[#002045] transition-all cursor-pointer">Privacy Policy</span>
          </div>

          <div className="flex flex-col gap-3">
            <h4 className="font-extrabold text-[#002045] uppercase tracking-wider text-[10px]">Subscribe</h4>
            <p className="text-gray-500">Get the latest verified luxury deals delivered to your inbox.</p>
            <form onSubmit={handleSubscribeNewsletter} className="flex gap-2">
              <input 
                type="email" 
                required
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                placeholder="Email address"
                className="bg-white border border-gray-200 rounded-lg px-3 py-2 text-xs w-full focus:outline-none focus:border-[#002045]"
              />
              <button 
                type="submit"
                className="bg-[#002045] hover:bg-[#003060] text-white p-2.5 rounded-lg cursor-pointer shrink-0"
              >
                <Send className="w-4 h-4 text-white" />
              </button>
            </form>
          </div>
        </div>

        {/* copyright metadata block */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 border-t border-gray-200/50 text-center text-gray-400 text-[11px]">
          © 2024 Zorify AI Marketplace. All Rights Reserved. Protected under regional Escrow covenants.
        </div>
      </footer>

      {/* Cart Slider Overlay drawer */}
      <CartDrawer 
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        currency={currency}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={() => setCart([])}
        forceStep={cartDrawerForceStep}
        triggerToast={triggerToast}
      />

      {/* Multi seller compare detail modal */}
      <ComparisonModal 
        product={comparisonProduct}
        isOpen={!!comparisonProduct}
        onClose={() => setComparisonProduct(null)}
        currency={currency}
        onAddToCart={handleAddToCartFromOffer}
      />

      {/* Interactive brand verification apply quiz modal */}
      <SellerApplyModal 
        isOpen={isSellerApplyOpen}
        onClose={() => setIsSellerApplyOpen(false)}
      />

      {/* Products Quick View inspect Modal */}
      {quickViewProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="absolute inset-0 bg-gray-900/60 backdrop-blur-xs cursor-pointer" onClick={() => setQuickViewProduct(null)} />
          <div className="relative bg-white rounded-3xl w-full max-w-lg p-6 shadow-2xl z-10 space-y-5 animate-fade-in text-left">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[10px] bg-[#002045]/5 px-2.5 py-1 rounded font-extrabold text-[#002045] uppercase tracking-wider">
                  {quickViewProduct.category}
                </span>
                <h3 className="text-base font-extrabold text-gray-900 mt-2">{quickViewProduct.title}</h3>
              </div>
              <button onClick={() => setQuickViewProduct(null)} className="p-1 text-gray-400 hover:text-gray-600 rounded-full cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <img 
              src={quickViewProduct.image} 
              alt={quickViewProduct.title} 
              className="w-full aspect-video rounded-2xl object-cover bg-gray-50 border border-gray-150"
              referrerPolicy="no-referrer"
            />

            <p className="text-xs text-gray-500 leading-relaxed">{quickViewProduct.description}</p>

            {quickViewProduct.specifications && (
              <div className="bg-gray-50 p-4 rounded-xl space-y-2 text-xs border border-gray-100">
                <h4 className="font-extrabold text-[#002045] uppercase tracking-wider text-[10px]">Specifications</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-gray-600">
                  {Object.entries(quickViewProduct.specifications).map(([k, v]) => (
                    <div key={k}>
                      <span className="text-gray-400 font-medium">{k}:</span> <strong>{v}</strong>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex items-center justify-between pt-2">
              <div>
                <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Buy Value Starts At</p>
                <p className="text-lg font-black text-emerald-600">
                  {formatPriceGlobal(quickViewProduct.pricePKR, quickViewProduct.priceUSD)}
                </p>
              </div>

              <button 
                onClick={() => {
                  setComparisonProduct(quickViewProduct);
                  setQuickViewProduct(null);
                }}
                className="bg-[#002045] hover:bg-[#003060] text-white px-5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1 cursor-pointer shadow-sm transition-all"
              >
                <Lock className="w-4 h-4 text-emerald-400" />
                Compare & Select Seller
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Live Email Notification Alerts Modal */}
      {showNotificationModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="absolute inset-0 bg-gray-900/60 backdrop-blur-xs cursor-pointer" onClick={() => setShowNotificationModal(false)} />
          <div className="relative bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl z-10 space-y-5 text-left text-xs">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-50 rounded-xl border border-amber-200">
                  <Bell className="w-5 h-5 text-amber-600 animate-bounce" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-gray-900">Subscribe to Live Alerts</h3>
                  <p className="text-[10px] text-gray-400">Get notified instantly about catalog drops & trade activity</p>
                </div>
              </div>
              <button onClick={() => setShowNotificationModal(false)} className="p-1 text-gray-400 hover:text-gray-600 rounded-full cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-gray-500 leading-relaxed">
              <p>
                No login is required! Simply click and register your email to activate automated real-time dispatch logs. You will receive immediate notifications when:
              </p>
              
              <div className="space-y-2.5">
                <div className="flex gap-2.5 items-start bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                  <span className="text-amber-500 text-xs mt-0.5">🔔</span>
                  <div>
                    <span className="font-bold text-gray-800">New Product Drops:</span>
                    <span className="text-[11px] block text-gray-500 mt-0.5">Whenever a vendor lists premium certified goods.</span>
                  </div>
                </div>

                <div className="flex gap-2.5 items-start bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                  <span className="text-emerald-500 text-xs mt-0.5">🚀</span>
                  <div>
                    <span className="font-bold text-gray-800">Dropship Catalog Syncs:</span>
                    <span className="text-[11px] block text-gray-500 mt-0.5">When trending items are synced with exact 15% margin markup.</span>
                  </div>
                </div>

                <div className="flex gap-2.5 items-start bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                  <span className="text-sky-500 text-xs mt-0.5">🛡️</span>
                  <div>
                    <span className="font-bold text-gray-800">Secure Escrow Activity:</span>
                    <span className="text-[11px] block text-gray-500 mt-0.5">Live reporting of secure trade covenants and purchase agreements.</span>
                  </div>
                </div>
              </div>

              <form onSubmit={handleSubscribeNotifications} className="space-y-3 pt-1">
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400">
                    <Mail className="w-4 h-4" />
                  </span>
                  <input
                    type="email"
                    required
                    value={notificationEmail}
                    onChange={(e) => setNotificationEmail(e.target.value)}
                    placeholder="Enter your active email (e.g. user@domain.com)"
                    className="w-full pl-10 pr-3 py-3 bg-gray-50 border border-gray-200 focus:border-[#002045] focus:outline-none focus:ring-4 focus:ring-sky-100 rounded-xl text-xs font-sans text-gray-900"
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full bg-[#002045] hover:bg-[#003060] text-white py-3 rounded-xl font-bold cursor-pointer transition-colors shadow-sm flex items-center justify-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Activate Free Email Notifications
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* How it Works / Protection Policy modal */}
      {showHowItWorks && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="absolute inset-0 bg-gray-900/60 backdrop-blur-xs cursor-pointer" onClick={() => setShowHowItWorks(false)} />
          <div className="relative bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl z-10 space-y-5 text-left text-xs">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <h3 className="text-sm font-bold text-gray-900">Zorify Safe Buy Guarantee</h3>
              </div>
              <button onClick={() => setShowHowItWorks(false)} className="p-1 text-gray-400 hover:text-gray-600 rounded-full cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-gray-500 leading-relaxed">
              <p>
                Traditional e-commerce lists thousands of unverified merchants, exposing buyers to delays, defective goods, and counterfeit risk. Zorify eliminates this entirely.
              </p>
              
              <div className="space-y-3">
                <div className="flex gap-3 items-start bg-emerald-50/70 p-3 rounded-xl border border-emerald-100">
                  <div className="p-1 rounded-lg bg-emerald-500 text-white shrink-0 mt-0.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-[#002045] text-xs">Escrow Protection Lock</h4>
                    <p className="text-[11px] text-gray-500 mt-1">
                      Our platform securely reserves payments. Cash remains safely in Zorify Escrow covenants. It is only dispersed to the merchant after proof of successful delivery.
                    </p>
                  </div>
                </div>

                <div className="flex gap-3 items-start bg-emerald-50/70 p-3 rounded-xl border border-emerald-100">
                  <div className="p-1 rounded-lg bg-emerald-500 text-white shrink-0 mt-0.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-[#002045] text-xs">Aesthetic Integrity Verification</h4>
                    <p className="text-[11px] text-gray-500 mt-1">
                      Merchants are audited frequently under ZV protocols checking for fake inventories, late fulfillment rates, and customer reviews.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <button 
              onClick={() => setShowHowItWorks(false)}
              className="w-full bg-[#002045] hover:bg-[#003060] text-white py-3 rounded-xl font-bold cursor-pointer"
            >
              Understand & Acknowledge
            </button>
          </div>
        </div>
      )}

      {/* SOS Support Help centers */}
      {showSOS && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="absolute inset-0 bg-gray-900/60 backdrop-blur-xs cursor-pointer" onClick={() => setShowSOS(false)} />
          <div className="relative bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl z-10 space-y-5 text-left text-xs">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-sky-600" />
                <h3 className="text-sm font-bold text-gray-900">Zorify SOS Emergency Support</h3>
              </div>
              <button onClick={() => setShowSOS(false)} className="p-1 text-gray-400 hover:text-gray-600 rounded-full cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-gray-500 leading-relaxed">
              <p>
                Have an active dispute, damaged shipment, or delivery delay? Our SOS support team operates 24/7 with immediate escrow mediation services.
              </p>
              
              <div className="bg-sky-50 border border-sky-100 p-4 rounded-xl space-y-1.5 text-sky-800">
                <div className="flex justify-between font-bold">
                  <span>Support Status</span>
                  <span className="text-emerald-600">● LIVE</span>
                </div>
                <p className="text-[11px] text-sky-700">Avg Mediated Resolution Speed: <strong>1.4 Hours</strong></p>
              </div>

              <div className="space-y-2">
                <p className="font-extrabold text-[10px] uppercase text-gray-400 tracking-wider">CHANNELS</p>
                <div className="grid grid-cols-2 gap-3 text-center">
                  <div className="p-3 bg-gray-50 border border-gray-100 rounded-xl">
                    <p className="font-bold text-gray-900">Live Chat Help</p>
                    <p className="text-[10px] text-gray-400 mt-1">Instant Applet</p>
                  </div>
                  <div className="p-3 bg-gray-50 border border-gray-100 rounded-xl">
                    <p className="font-bold text-gray-900">Audit Desk</p>
                    <p className="text-[10px] text-gray-400 mt-1">mediation@zorify.com</p>
                  </div>
                </div>
              </div>
            </div>

            <button 
              onClick={() => {
                setShowSOS(false);
                triggerToast('SOS Mediation ticket initialized.');
              }}
              className="w-full bg-[#002045] hover:bg-[#003060] text-white py-3 rounded-xl font-bold cursor-pointer"
            >
              Open Direct SOS Dispute Ticket
            </button>
          </div>
        </div>
      )}

      {/* Invite Friends Referral Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="absolute inset-0 bg-gray-900/60 backdrop-blur-xs cursor-pointer" onClick={() => setShowInviteModal(false)} />
          <form onSubmit={handleSendInvite} className="relative bg-white rounded-3xl w-full max-w-sm p-6 shadow-2xl z-10 space-y-4 text-left text-xs">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-2">
                <Gift className="w-5 h-5 text-emerald-600 animate-bounce" />
                <h3 className="text-sm font-bold text-gray-900">Invite a Partner</h3>
              </div>
              <button type="button" onClick={() => setShowInviteModal(false)} className="p-1 text-gray-400 hover:text-gray-600 rounded-full cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-gray-500 leading-relaxed">
              Dispatch invitations and secure 50 free coins when they finalize their first safe Escrow buyout!
            </p>

            <div className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold text-gray-500 mb-1">PARTNER FULL NAME</label>
                <input 
                  type="text" 
                  required
                  value={inviteName}
                  onChange={(e) => setInviteName(e.target.value)}
                  placeholder="e.g. Zain"
                  className="w-full px-3.5 py-2 bg-gray-50 border border-gray-200 focus:border-emerald-500 focus:outline-none rounded-xl text-xs text-gray-900"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-500 mb-1">PARTNER EMAIL</label>
                <input 
                  type="email" 
                  required
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  placeholder="e.g. zain@outlook.com"
                  className="w-full px-3.5 py-2 bg-gray-50 border border-gray-200 focus:border-emerald-500 focus:outline-none rounded-xl text-xs text-gray-900"
                />
              </div>
            </div>

            <button 
              type="submit"
              className="w-full bg-[#002045] hover:bg-[#003060] text-white py-3 rounded-xl font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
            >
              <Send className="w-3.5 h-3.5 text-emerald-300" />
              Dispatch Invite Request
            </button>
          </form>
        </div>
      )}

      {isLaunchControlOpen && (
        <LaunchControl 
          onClose={() => setIsLaunchControlOpen(false)}
          currency={currency}
          onLoginSuccess={(user) => {
            setCurrentUser(user);
            localStorage.setItem('zorify-current-user', JSON.stringify(user));
            setIsLaunchControlOpen(false);
            triggerToast(`Operations Desk Access Granted. Welcome back, agent ${user.username}!`);
          }}
        />
      )}

    </div>
  );
}
